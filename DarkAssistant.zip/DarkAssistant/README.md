# Dark Assistant

Ek offline, fully on-device JARVIS. Bolne par phone ke asli kaam karta hai —
torch, call, SMS, apps, volume, alarm, back/home/recents, screenshot, screen
padhna, tap karna. Koi cloud nahi, koi API key nahi. Command parsing aur
execution sab phone ke andar.

Package: `com.dark.assistant`
Min: Android 7.0 (API 24) · Target: Android 14 (API 34)

---

## 1. Build kaise karein (3 tareeke)

Ye project **normal Gradle project** hai. Build ke liye JDK 17 + Android SDK 34
chahiye, jo sirf phone par nahi hote — isliye neeche options diye hain.

### A) GitHub Actions — sabse aasan, bilkul free, phone se hi ho jayega

Repo mein `.github/workflows/build-apk.yml` already daal diya hai.

1. GitHub account banao (agar nahi hai).
2. Naya **private/public repo** banao, yeh poori `DarkAssistant` folder usme upload karo
   (GitHub app se folder upload ho jata hai, ya Termux: `git init && git push`).
3. Repo → **Actions** tab → "Build APK" workflow → **Run workflow**.
4. ~5 min baad wahi run kholo → neeche **Artifacts** → `dark-assistant-debug` download.
5. APK ko phone par install karo (Settings → "Install unknown apps" allow).

Yahi recommended hai. Na phone garam hoga, na 8GB SDK download karna padega.

### B) AIDE Pro (phone par hi, offline)

Tumhare phone par AIDE already hai. Par dhyan do:

- **AIDE ka purana free version is project ko build NAHI karega** — usme AGP 8.
  aur Kotlin support kamzor hai. **AIDE Pro** hi try karo.
- Best: AIDE Pro → "Open project" → `/storage/emulated/0/MT2/DarkAssistant`
  → Gradle sync hone do. Pehli baar 200–400 MB dependencies download hongi
  (Material, AndroidX, Kotlin stdlib), isliye stable Wi-Fi chahiye.
- Agar sync fail ho → option C ya A use karo.

### C) Termux (proot-distro) — advanced, phone par hi

```
pkg install proot-distro
proot-distro install ubuntu
proot-distro login ubuntu
# andar:
apt update && apt install -y openjdk-17-jdk wget unzip git
# Android commandline-tools (sdkmanager) install karke:
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"
cd /path/to/DarkAssistant && ./gradlew assembleDebug
```

APK milega: `app/build/outputs/apk/debug/app-debug.apk`.
(Gradle wrapper jar is project mein nahi hai; agar `./gradlew` na chale to
`gradle` command use karo ya Android Studio se pehli baar sync karo.)

### D) PC / laptop par Android Studio (agar available ho)

1. Android Studio (Hedgehog ya naya) install karo, JDK 17 bundled hota hai.
2. **Open** → `/storage/emulated/0/MT2/DarkAssistant` (ya PC par copy).
3. Gradle sync khatam hone do.
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
   File: `app/build/outputs/apk/debug/app-debug.apk`.

> Debug APK self-signed hota hai — seedha install ho jata hai, koi Play Store
> account nahi chahiye.

---

## 2. Pehli baar chalane par — permission setup (is order mein do)

App kholne par **Setup** screen dikhega. Ek-ek item par tap karo:

| # | Permission | Kyun chahiye |
|---|-----------|--------------|
| 1 | **Microphone** | Aawaz sunna |
| 2 | **Notifications** (Android 13+) | Service ka status |
| 3 | **Contacts** | "Amit ko call karo" |
| 4 | **Phone** | Khud call lagana |
| 5 | **SMS** | Message bhejna |
| 6 | **Accessibility service** | Back / Home / Recents / Lock / Screenshot / Screen padhna / Tap |
| 7 | **Notification access** | Aaye hue message sunana |
| 8 | **Floating mic (overlay)** | Kisi bhi app ke upar mic button |
| 9 | **Battery: no restrictions** | Background mein band na ho |

**Accessibility ON karne ke baad ek baar app restart karo** (service register hone ke liye).

---

## 3. Kya-kya bol sakte ho (cheat sheet)

- **Apps:** "WhatsApp kholo", "camera open karo", "settings kholo"
- **Search:** "YouTube par lofi gaana chalao", "Google par weather search karo"
- **Music:** "Arijit Singh ke gane bajao", "music band karo" / "gaana roko"
- **Call/SMS:** "Amit ko call karo", "Papa ko message bhejo mil raha hoon",
  "Riya ko WhatsApp call karo" — call/SMS se pehle **confirm** poochta hai (haan/nahi)
- **Torch:** "torch on karo", "torch band karo", "phir se" (last on/off toggle)
- **Volume:** "volume 50 karo", "awaaz badhao", "mute karo"
- **Ringer:** "silent karo", "vibrate mode", "ringer on karo", "DND on karo"
- **Alarm/Timer:** "7 baje ka alarm lagao subah", "10 minute ka timer lagao"
- **Screen:** "back", "home", "recent apps", "lock karo", "screenshot lo", "screen padho"
- **Tap/Type:** "settings par tap karo", "niche scroll karo", "likho Namaste"
- **Info:** "battery kitni hai", "time kya hua", "aaj ki date", "phone ki info"
- **Calc:** "25 into 4 plus 10 kitna hota hai"
- **Notes:** "note likho doodh lena hai", "notes padho", "notes saaf karo"
- **Help:** "kya kar sakte ho" / "help"

Devanagari mein bolo ya Roman mein type karo — dono chalte hain (Normalizer
Devanagari ko Roman keyword space par fold karta hai).

---

## 4. Android jo nahi karne deta (ye jhooth nahi — sach hai)

Assistant khud bol dega jab kuch possible na ho:

- **Wi-Fi / Bluetooth / Airplane mode / Hotspot** — Android 10+ par apps inhe
  chupchap ON/OFF **nahi** kar sakte. Assistant exact system panel kholta hai
  ("Wi-Fi ka panel khol diya, wahin se on kar do"). Ye Google ka security rule hai.
- **Silent/ringer mode** — bina **DND access** ke silent nahi kar sakte.
  Assistant pehle DND access screen par bhejega.
- **Screenshot** — `takeScreenshot` sirf **Android 11 (API 30)+** par hai.
  Purane phone par reply aayega "Android 11+ chahiye".
- **Call uthana / kaatna** — `ANSWER_PHONE_CALLS` + **default dialer** hona chahiye,
  warna fail report karega (fake success nahi).
- **True wake word ("Bolo Dark")** — bina downloaded ML model ke background
  mein hamesha sunna Android background limits aur battery ki wajah se practical
  nahi. Isliye `WakeWordService` ek honest **status notification + one-tap launch**
  hai — nakli wake-word listener nahi. Asli wake word ke liye third-party engine
  (jaise Porcupine) chahiye hoga, jo extra library hai.

---

## 5. Structure

```
app/src/main/java/com/dark/assistant/
  engine/Command.kt          — sealed Command (~45 variants)
  engine/Normalizer.kt       — Devanagari→Roman, numbers, time, duration, contact
  engine/CommandParser.kt    — pure offline parser (~120 regex rules)
  engine/ActionExecutor.kt   — Command → asli device call → Hinglish reply
  engine/DeviceControl.kt    — torch/volume/ringer/DND/alarm/timer/battery
  engine/AppLauncher.kt      — app alias + label matching + levenshtein
  engine/CommsControl.kt     — contacts lookup, call, SMS, WhatsApp
  engine/PermissionGate.kt   — "allowed?" + grant screens + setup list
  engine/AssistantEngine.kt  — entry point, yes/no confirm flow, suggestions
  services/ControlAccessibilityService.kt — global actions, read/tap/type/screenshot
  services/AssistantServices.kt — Notifier, WakeWordService, BootReceiver
  services/NotificationWatcher.kt
  services/FloatingMicService.kt
  voice/Voice.kt             — on-device STT (Hindi) + Hindi TTS
  ui/MainActivity.kt, ui/SettingsActivity.kt, ui/ChatAdapter.kt
```

Sab kuch **offline** hai. Koi network permission app ke core kaam ke liye use
nahi hoti (sirf `SearchWeb`/`OpenUrl` browser intent bhejte hain, jo normal hai).
