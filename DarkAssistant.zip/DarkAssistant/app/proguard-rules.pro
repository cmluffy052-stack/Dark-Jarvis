# Keep the accessibility service and notification listener names intact.
-keep class com.dark.assistant.services.** { *; }
-dontwarn androidx.**