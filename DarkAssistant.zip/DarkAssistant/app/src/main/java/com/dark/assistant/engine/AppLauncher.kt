package com.dark.assistant.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.provider.Settings

/**
 * Finds and launches installed apps by fuzzy match on the spoken name.
 * Users say "insta", "wa", "yt", "gaana" — all of those have to hit the right
 * package without a hardcoded table being the only option.
 */
object AppLauncher {

    /** Spoken alias -> package name. Checked before fuzzy matching. */
    private val ALIASES = mapOf(
        "whatsapp" to "com.whatsapp",
        "watsapp" to "com.whatsapp",
        "wa" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "insta" to "com.instagram.android",
        "insta gram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "fb" to "com.facebook.katana",
        "youtube" to "com.google.android.youtube",
        "yt" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "browser" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "mail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "map" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "camera" to "com.google.android.GoogleCamera",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "phone" to "com.android.dialer",
        "dialer" to "com.android.dialer",
        "contacts" to "com.android.contacts",
        "messages" to "com.google.android.apps.messaging",
        "sms" to "com.google.android.apps.messaging",
        "settings" to "com.android.settings",
        "play store" to "com.android.vending",
        "playstore" to "com.android.vending",
        "spotify" to "com.spotify.music",
        "telegram" to "org.telegram.messenger",
        "snapchat" to "com.snapchat.android",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "netflix" to "com.netflix.mediaclient",
        "amazon" to "in.amazon.mShop.android.shopping",
        "flipkart" to "com.flipkart.android",
        "paytm" to "net.one97.paytm",
        "gpay" to "com.google.android.apps.nbu.paisa.user",
        "phonepe" to "com.phonepe.app",
        "calculator" to "com.google.android.calculator",
        "clock" to "com.google.android.deskclock",
        "alarm" to "com.google.android.deskclock",
        "calendar" to "com.google.android.calendar",
        "notes" to "com.google.android.keep",
        "keep" to "com.google.android.keep",
        "files" to "com.google.android.documentsui",
        "file manager" to "com.google.android.documentsui",
        "truecaller" to "com.truecaller",
        "mx player" to "com.mxtech.videoplayer.ad",
        "vlc" to "org.videolan.vlc",
        "free fire" to "com.dts.freefireth",
        "freefire" to "com.dts.freefireth",
        "bgmi" to "com.pubg.imobile",
        "pubg" to "com.tencent.ig"
    )

    data class AppEntry(val label: String, val pkg: String)

    /** All launchable apps, cached per process. */
    private var cache: List<AppEntry>? = null

    fun installedApps(context: Context): List<AppEntry> {
        cache?.let { if (it.isNotEmpty()) return it }
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list: List<ResolveInfo> = try {
            pm.queryIntentActivities(intent, 0)
        } catch (_: Throwable) {
            emptyList()
        }
        val out = list.mapNotNull { ri ->
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            val label = ri.loadLabel(pm).toString()
            AppEntry(label, pkg)
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        cache = out
        return out
    }

    fun invalidate() { cache = null }

    /** Resolves a spoken app name to a launchable package, or null. */
    fun resolve(context: Context, spokenRaw: String): AppEntry? {
        val spoken = spokenRaw.trim().lowercase()
            .removeSuffix(" app").removeSuffix(" application")
            .trim()
        if (spoken.isEmpty()) return null

        val apps = installedApps(context)

        // 1. Alias table, only if that package is really installed.
        ALIASES[spoken]?.let { pkg ->
            apps.firstOrNull { it.pkg == pkg }?.let { return it }
        }

        // 2. Exact label match (case-insensitive).
        apps.firstOrNull { it.label.equals(spoken, ignoreCase = true) }?.let { return it }

        // 3. Label starts with / contains the spoken words.
        apps.firstOrNull { it.label.lowercase().startsWith(spoken) }?.let { return it }
        apps.firstOrNull { it.label.lowercase().contains(spoken) }?.let { return it }

        // 4. Spoken words fuzzy-match a package segment ("freefire" -> fire).
        val tokens = spoken.split(' ', '.', '-').filter { it.length >= 3 }
        apps.firstOrNull { app ->
            val pkg = app.pkg.lowercase()
            val label = app.label.lowercase()
            tokens.any { t -> label.contains(t) || pkg.contains(t) }
        }?.let { return it }

        // 5. Cheap edit distance on the first word.
        val target = spoken.split(' ').first()
        return apps
            .map { it to levenshtein(target, it.label.lowercase().split(' ').first()) }
            .filter { it.second <= 2 }
            .minByOrNull { it.second }?.first
    }

    /** Launches an app. Returns what happened, in Hinglish. */
    fun open(context: Context, spoken: String): Result {
        // A few spoken names mean "open this screen", not "launch an app".
        settingsShortcut(spoken)?.let { return openIntent(context, it, spoken) }

        val app = resolve(context, spoken)
            ?: return Result(false, "Mujhe \"$spoken\" naam ka koi installed app nahi mila.")

        val i = context.packageManager.getLaunchIntentForPackage(app.pkg)
            ?: return Result(false, "${app.label} launch nahi ho paya.")
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            context.startActivity(i)
            Result(true, "${app.label} khol raha hoon.")
        } catch (e: Throwable) {
            Result(false, "${app.label} khol nahi paya.")
        }
    }

    private fun settingsShortcut(spoken: String): Intent? {
        val s = spoken.lowercase()
        val action = when {
            s.contains("setting") && s.contains("wifi") -> Settings.ACTION_WIFI_SETTINGS
            s.contains("setting") && s.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
            s.contains("setting") && s.contains("display") -> Settings.ACTION_DISPLAY_SETTINGS
            s.contains("setting") && s.contains("sound") -> Settings.ACTION_SOUND_SETTINGS
            s.contains("setting") && s.contains("battery") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            s.contains("setting") && s.contains("storage") -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            s.contains("setting") && s.contains("app") -> Settings.ACTION_APPLICATION_SETTINGS
            s.contains("setting") && s.contains("location") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            s.contains("setting") && s.contains("language") -> Settings.ACTION_LOCALE_SETTINGS
            s.contains("setting") && s.contains("accessibility") -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            s.contains("setting") && s.contains("date") -> Settings.ACTION_DATE_SETTINGS
            s.contains("setting") && s.contains("notification") -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            s.contains("setting") && s.contains("security") -> Settings.ACTION_SECURITY_SETTINGS
            else -> null
        } ?: return null
        return Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun openIntent(context: Context, intent: Intent, spoken: String): Result {
        return try {
            context.startActivity(intent)
            Result(true, "$spoken settings khol di.")
        } catch (e: Throwable) {
            Result(false, "$spoken settings nahi khuli.")
        }
    }

    /** Settings screens addressed by their spoken Hindi/English name. */
    fun openSettings(context: Context, spoken: String): Result {
        val s = spoken.lowercase().trim()
        if (s.isEmpty()) {
            return try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Result(true, "Settings khol di.")
            } catch (e: Throwable) {
                Result(false, "Settings nahi khuli.")
            }
        }
        val action = when {
            s.contains("wifi") || s.contains("internet") -> Settings.ACTION_WIFI_SETTINGS
            s.contains("bluetooth") || s.contains("bt") -> Settings.ACTION_BLUETOOTH_SETTINGS
            s.contains("data") -> Settings.ACTION_DATA_ROAMING_SETTINGS
            s.contains("display") || s.contains("screen") -> Settings.ACTION_DISPLAY_SETTINGS
            s.contains("sound") || s.contains("awaz") -> Settings.ACTION_SOUND_SETTINGS
            s.contains("battery") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            s.contains("storage") || s.contains("memory") -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            s.contains("app") -> Settings.ACTION_APPLICATION_SETTINGS
            s.contains("location") || s.contains("gps") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            s.contains("language") || s.contains("bhasha") -> Settings.ACTION_LOCALE_SETTINGS
            s.contains("accessibility") -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            s.contains("date") || s.contains("time") -> Settings.ACTION_DATE_SETTINGS
            s.contains("notification") -> Settings.ACTION_NOTIFICATION_SETTINGS
            s.contains("security") || s.contains("lock") -> Settings.ACTION_SECURITY_SETTINGS
            s.contains("dnd") || s.contains("do not disturb") -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
            s.contains("hotspot") || s.contains("tether") -> Settings.ACTION_WIRELESS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result(true, "Settings khol di.")
        } catch (e: Throwable) {
            Result(false, "Settings nahi khuli.")
        }
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }
}
