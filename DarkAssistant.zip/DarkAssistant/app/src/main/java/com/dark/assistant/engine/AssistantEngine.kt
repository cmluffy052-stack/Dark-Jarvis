package com.dark.assistant.engine

import android.content.Context
import com.dark.assistant.data.ChatStore

/**
 * The front door for one conversational turn: parse, execute, remember.
 *
 * The UI only ever calls [handle]; everything about permissions, confirmation
 * and fallbacks stays in here so the chat screen stays dumb.
 */
class AssistantEngine(
    private val context: Context,
    private val permissions: PermissionGate,
    screenControl: ScreenControl?
) {

    val executor = ActionExecutor(context, permissions, screenControl)

    /** Set when the previous turn asked a yes/no question. */
    private var awaitingConfirm = false

    /**
     * Handles a user turn and returns the assistant's reply.
     * An empty string means "reply already handled elsewhere" (screenshot etc.).
     */
    fun handle(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return ""

        // A pending "call karun?" / "SMS bhejun?" is answered first.
        if (awaitingConfirm) {
            awaitingConfirm = false
            val yes = isAffirmative(text)
            val no = isNegative(text)
            if (yes) {
                return executor.confirmPending() ?: "Ho gaya."
            }
            if (no) {
                return executor.cancelPending()
            }
            // Anything else: drop the pending action and treat it as a new command.
            executor.cancelPending()
        }

        val command = CommandParser.parse(text)

        // "stop" should also silence speech, which the UI does.
        val reply = executor.execute(command)
        if (executor.hasPendingConfirmation()) {
            awaitingConfirm = true
            return executor.pendingConfirmPrompt ?: reply
        }
        return reply
    }

    private fun isAffirmative(text: String): Boolean {
        val t = Normalizer.normalize(text)
        return t == "haan" || t == "han" || t == "yes" || t == "ya" || t == "yep" ||
            t == "ok" || t == "okay" || t == "theek hai" || t == "thik hai" ||
            t == "bilkul" || t == "kar do" || t == "karo" || t == "ha" ||
            t.startsWith("haan ") || t.startsWith("yes ")
    }

    private fun isNegative(text: String): Boolean {
        val t = Normalizer.normalize(text)
        return t == "nahi" || t == "no" || t == "nope" || t == "mat karo" ||
            t == "cancel" || t == "rehne do" || t.startsWith("nahi ") || t.startsWith("no ")
    }

    fun clearPending() {
        if (awaitingConfirm) {
            executor.cancelPending()
            awaitingConfirm = false
        }
    }

    /** Suggestions shown as chips above the input. */
    fun suggestions(): List<String> = listOf(
        "Torch on karo",
        "WhatsApp kholo",
        "Battery kitni hai",
        "Screenshot lo",
        "Silent mode",
        "7 baje alarm",
        "Sonia ko call karo",
        "Volume 50",
        "Notes dikhao",
        "Help"
    )
}

/** Chat persistence helper kept out of the activity. */
object History {
    fun save(context: Context, messages: List<ChatStore.Message>) =
        ChatStore.save(context, messages)

    fun load(context: Context): List<ChatStore.Message> = ChatStore.load(context)

    fun clear(context: Context) = ChatStore.clear(context)
}
