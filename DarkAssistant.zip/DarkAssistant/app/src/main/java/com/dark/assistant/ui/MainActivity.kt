package com.dark.assistant.ui

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dark.assistant.R
import com.dark.assistant.data.ChatStore
import com.dark.assistant.data.Prefs
import com.dark.assistant.engine.AssistantEngine
import com.dark.assistant.engine.Command
import com.dark.assistant.engine.CommandParser
import com.dark.assistant.engine.PermissionGate
import com.dark.assistant.engine.ScreenControl
import com.dark.assistant.services.ControlAccessibilityService
import com.dark.assistant.services.NotificationWatcher
import com.dark.assistant.services.ScreenshotBridge
import com.dark.assistant.services.WakeWordService
import com.dark.assistant.voice.SpeechInput
import com.dark.assistant.voice.SpeechOutput

/**
 * The whole assistant in one screen: transcript, mic, text input, and the
 * permission/setup sheet.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var adapter: ChatAdapter
    private lateinit var chatList: RecyclerView
    private lateinit var input: EditText
    private lateinit var micButton: FrameLayout
    private lateinit var statusLine: TextView
    private lateinit var suggestionRow: LinearLayout

    private lateinit var permissions: PermissionGate
    private lateinit var engine: AssistantEngine
    private lateinit var voiceOut: SpeechOutput
    private var voiceIn: SpeechInput? = null

    private var listening = false
    private var pendingBubbleIndex = -1
    private var pulse: ValueAnimator? = null

    private val requestMic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening()
        else addBot("Microphone permission nahi mili. Settings se do, ya type karke bolo.")
    }

    private val requestBundle = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val denied = result.filterValues { !it }.keys
        if (denied.isNotEmpty()) {
            addBot("Kuch permissions nahi mili: ${denied.joinToString { it.substringAfterLast('.') }}.")
        } else {
            addBot("Permissions mil gayi. Ab bolo.")
        }
        refreshSetupBadge()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        permissions = PermissionGate(this)
        val screenControl: ScreenControl? = ControlAccessibilityService.instance
        engine = AssistantEngine(this, permissions, screenControl)
        voiceOut = SpeechOutput(this)

        chatList = findViewById(R.id.chatList)
        input = findViewById(R.id.input)
        micButton = findViewById(R.id.micButton)
        statusLine = findViewById(R.id.statusLine)
        suggestionRow = findViewById(R.id.suggestionRow)

        adapter = ChatAdapter { text -> copyToClipboard(text) }
        val lm = LinearLayoutManager(this).apply { stackFromEnd = true }
        chatList.layoutManager = lm
        chatList.adapter = adapter

        // Restore history, or greet on a fresh install.
        val history = com.dark.assistant.engine.History.load(this)
        if (history.isEmpty()) {
            adapter.add(ChatStore.Message(getString(R.string.greeting), false))
        } else {
            adapter.submit(history)
        }
        scrollToBottom()

        findViewById<ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.clearButton).setOnClickListener { confirmClear() }
        findViewById<ImageButton>(R.id.sendButton).setOnClickListener { sendCurrentInput() }

        input.setOnEditorActionListener { _, actionId, event ->
            val isSend = actionId == EditorInfo.IME_ACTION_SEND ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            if (isSend) {
                sendCurrentInput()
                true
            } else false
        }

        micButton.setOnClickListener { toggleListening() }

        buildSuggestions()

        // Screenshot / screen-read callbacks from the accessibility service.
        ScreenshotBridge.listener = { path ->
            runOnUiThread {
                if (path.isNotEmpty()) {
                    addBot("Screenshot save ho gaya: ${path.substringAfterLast('/')}\n$path")
                }
            }
        }
        ScreenshotBridge.failureListener = { message ->
            runOnUiThread { addBot(message) }
        }

        if (!Prefs.setupShown) {
            Prefs.setupShown = true
            showSetupDialog()
        }
        refreshSetupBadge()
        handleLaunchIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    /** Supports `adb shell am start ... --es cmd "torch on"`. */
    private fun handleLaunchIntent(intent: Intent?) {
        val cmd = intent?.getStringExtra("cmd")
        if (!cmd.isNullOrBlank()) {
            send(cmd)
        }
        if (intent?.getBooleanExtra(EXTRA_START_LISTENING, false) == true) {
            micButton.postDelayed({ if (!listening) toggleListening() }, 400)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSetupBadge()
        voiceOut.refreshSettings()
        // Rebuild the engine so a freshly enabled accessibility service is picked up.
        engine = AssistantEngine(this, permissions, ControlAccessibilityService.instance)
        if (Prefs.wakeWordEnabled && !WakeWordService.running) {
            try { WakeWordService.start(this) } catch (_: Throwable) { }
        }
        com.dark.assistant.services.FloatingMicService.refresh(this)
        NotificationWatcher.listener = { event ->
            if (Prefs.announceNotifications) {
                runOnUiThread {
                    val line = "${event.app}: ${event.title} ${event.text}".trim()
                    if (line.isNotBlank()) {
                        addBot("🔔 $line")
                        if (Prefs.speakReplies) voiceOut.speak(line)
                    }
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        NotificationWatcher.listener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceIn?.stop()
        voiceOut.shutdown()
        ScreenshotBridge.listener = null
        ScreenshotBridge.failureListener = null
        com.dark.assistant.engine.History.save(this, adapter.all())
    }

    // ------------------------------------------------------------- listening

    private fun toggleListening() {
        if (listening) {
            voiceIn?.stop()
            setListeningUi(false)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startListening()
    }

    private fun startListening() {
        voiceOut.stop()
        val si = SpeechInput(this)
        voiceIn = si
        si.onListeningChanged = { active -> runOnUiThread { setListeningUi(active) } }
        si.onPartial = { partial ->
            runOnUiThread {
                statusLine.text = partial.ifBlank { getString(R.string.listening) }
            }
        }
        si.onResult = { text ->
            runOnUiThread {
                setListeningUi(false)
                send(text)
            }
        }
        si.onError = { message ->
            runOnUiThread {
                setListeningUi(false)
                statusLine.text = getString(R.string.status_idle)
                addBot(message)
            }
        }
        si.onRms = { rms ->
            runOnUiThread {
                val scale = ((rms.coerceIn(-2f, 10f) + 2f) / 12f)
                micButton.scaleX = 1f + scale * 0.12f
                micButton.scaleY = 1f + scale * 0.12f
            }
        }
        si.start()
    }

    private fun setListeningUi(active: Boolean) {
        listening = active
        micButton.setBackgroundResource(
            if (active) R.drawable.bg_mic_listening else R.drawable.bg_mic
        )
        if (!active) {
            micButton.scaleX = 1f
            micButton.scaleY = 1f
            statusLine.text = getString(R.string.status_idle)
            stopPulse()
        } else {
            statusLine.text = getString(R.string.listening)
            startPulse()
        }
    }

    private fun startPulse() {
        stopPulse()
        pulse = ValueAnimator.ofFloat(1f, 1.08f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                micButton.alpha = 0.88f + 0.12f * (it.animatedValue as Float - 1f) * 12f
            }
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        micButton.alpha = 1f
    }

    // ------------------------------------------------------------- messaging

    private fun sendCurrentInput() {
        val text = input.text?.toString().orEmpty().trim()
        if (text.isEmpty()) return
        input.setText("")
        send(text)
    }

    private fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return

        voiceOut.stop()
        adapter.add(ChatStore.Message(clean, true))
        scrollToBottom()

        statusLine.text = getString(R.string.thinking)
        // A tiny delay keeps the UI honest for slow actions (screenshot, dialer).
        micButton.postDelayed({
            val reply = try {
                engine.handle(clean)
            } catch (t: Throwable) {
                "Kuch gadbad ho gayi: ${t.message ?: t.javaClass.simpleName}"
            }
            statusLine.text = getString(R.string.status_idle)
            if (reply.isNotBlank()) {
                addBot(reply)
                if (Prefs.speakReplies) voiceOut.speak(reply)
            }
            com.dark.assistant.engine.History.save(this, adapter.all())
        }, 120)
    }

    private fun addBot(text: String) {
        adapter.add(ChatStore.Message(text, false))
        scrollToBottom()
    }

    private fun scrollToBottom() {
        chatList.post {
            val last = adapter.itemCount - 1
            if (last >= 0) chatList.smoothScrollToPosition(last)
        }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(android.content.ClipboardManager::class.java)
        cm?.setPrimaryClip(android.content.ClipData.newPlainText("Dark Assistant", text))
        statusLine.text = getString(R.string.copied_hint)
        statusLine.postDelayed({ statusLine.text = getString(R.string.status_idle) }, 1400)
    }

    // ------------------------------------------------------------ suggestions

    private fun buildSuggestions() {
        suggestionRow.removeAllViews()
        engine.suggestions().forEach { label ->
            val chip = layoutInflater.inflate(R.layout.item_chip, suggestionRow, false)
            chip.findViewById<TextView>(R.id.chipText).text = label
            chip.setOnClickListener { send(label) }
            suggestionRow.addView(chip)
        }
    }

    // ----------------------------------------------------------------- setup

    private fun showSetupDialog() {
        showSetupSheet()
    }

    private fun showSetupSheet() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.setup_title)
            .setMessage(R.string.setup_subtitle)
            .setView(container)
            .setNegativeButton(R.string.close, null)
            .setPositiveButton("Mic + Phone") { _, _ -> requestCorePermissions() }
            .create()

        permissions.setupItems().forEach { item ->
            val row = layoutInflater.inflate(R.layout.item_setting_action, container, false)
            row.findViewById<TextView>(R.id.title).text = item.title
            row.findViewById<TextView>(R.id.subtitle).text = item.subtitle
            val status = row.findViewById<TextView>(R.id.status)
            status.text = if (item.granted) getString(R.string.granted) else getString(R.string.grant)
            status.setTextColor(
                ContextCompat.getColor(
                    this,
                    if (item.granted) R.color.da_ok else R.color.da_accent
                )
            )
            row.setOnClickListener {
                requestSetupItem(item)
                dialog.dismiss()
            }
            container.addView(row)
        }
        dialog.show()
    }

    private fun requestSetupItem(item: PermissionGate.SetupItem) {
        when (item.kind) {
            PermissionGate.Kind.RUNTIME -> {
                val p = item.permission
                if (p != null) requestBundle.launch(arrayOf(p))
            }
            PermissionGate.Kind.ACCESSIBILITY -> {
                addBot("Settings khol raha hoon — \"Dark Assistant\" ko ON karo.")
                permissions.openAccessibilitySettings()
            }
            PermissionGate.Kind.NOTIFICATION_ACCESS -> {
                addBot("Notification access khol raha hoon — Dark Assistant ko allow karo.")
                permissions.openNotificationAccessSettings()
            }
            PermissionGate.Kind.OVERLAY -> {
                addBot("Overlay permission khol raha hoon.")
                permissions.openOverlaySettings()
                Prefs.floatingMic = true
            }
            PermissionGate.Kind.BATTERY -> {
                addBot("Battery optimization hatane ki screen khol raha hoon.")
                com.dark.assistant.engine.DeviceControl.requestIgnoreBatteryOptimizations(this)
            }
        }
        refreshSetupBadge()
    }

    private fun requestCorePermissions() {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestBundle.launch(list.toTypedArray())
    }

    private fun refreshSetupBadge() {
        val items = permissions.setupItems()
        val granted = items.count { it.granted }
        statusLine.text = if (granted == items.size) "Sab set — bolo" else "$granted/${items.size} permissions"
    }

    // --------------------------------------------------------------- helpers

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_chat)
            .setMessage("Poori chat history delete ho jayegi.")
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.clear_chat) { _, _ ->
                adapter.clear()
                com.dark.assistant.engine.History.clear(this)
                addBot(getString(R.string.greeting))
            }
            .show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_START_LISTENING = "start_listening"
    }
}
