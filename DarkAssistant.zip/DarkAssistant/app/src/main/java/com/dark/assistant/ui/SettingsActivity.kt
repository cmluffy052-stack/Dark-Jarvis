package com.dark.assistant.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.dark.assistant.R
import com.dark.assistant.data.Prefs
import com.dark.assistant.engine.DeviceControl
import com.dark.assistant.engine.PermissionGate
import com.dark.assistant.services.WakeWordService
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

/**
 * Settings + permission dashboard. Everything here maps to a real device
 * capability; rows update their status when the activity resumes.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var permissions: PermissionGate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        container = findViewById(R.id.settingsContainer)
        permissions = PermissionGate(this)
        rebuild()
    }

    override fun onResume() {
        super.onResume()
        rebuild()
    }

    private fun rebuild() {
        container.removeAllViews()

        section("Voice & speech")
        switchRow(
            "Speak my replies",
            "Har jawab ko aawaz mein bolega.",
            Prefs.speakReplies
        ) { Prefs.speakReplies = it }

        switchRow(
            "Announce notifications",
            "Naya message aaye to padh kar sunayega (notification access chahiye).",
            Prefs.announceNotifications
        ) { Prefs.announceNotifications = it }

        switchRow(
            "Wake word listening",
            "Status service chalu rakhega. Asli wake word ke liye model download chahiye — yahan se sirf ready-rakhne wala notification chalta hai.",
            Prefs.wakeWordEnabled
        ) { enabled ->
            Prefs.wakeWordEnabled = enabled
            if (enabled) {
                try { WakeWordService.start(this) } catch (_: Throwable) { }
            } else {
                WakeWordService.stop(this)
            }
            toast(if (enabled) "Listener on" else "Listener off")
        }

        sliderRow(
            "Speech rate",
            "${"%.1f".format(Prefs.speechRate)}x",
            Prefs.speechRate, 0.5f, 2.0f
        ) { Prefs.speechRate = it }

        pickerRow(
            "Language",
            languageLabel(Prefs.language)
        ) {
            val labels = arrayOf("हिंदी (hi-IN)", "English (en-IN)", "English (en-US)")
            val values = arrayOf("hi-IN", "en-IN", "en-US")
            val current = values.indexOf(Prefs.language).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("Language")
                .setSingleChoiceItems(labels, current) { d, which ->
                    Prefs.language = values[which]
                    d.dismiss()
                    rebuild()
                }
                .show()
        }

        section("Phone control")
        switchRow(
            "Confirm before calling",
            "Call se pehle haan/nahi poochega.",
            Prefs.confirmCalls
        ) { Prefs.confirmCalls = it }

        switchRow(
            "Confirm before sending SMS",
            "Message bhejne se pehle confirm karega.",
            Prefs.confirmSms
        ) { Prefs.confirmSms = it }

        switchRow(
            "Save chat history",
            "App band hone ke baad bhi chat rahegi.",
            Prefs.saveHistory
        ) { Prefs.saveHistory = it }

        section("Permissions")
        permissions.setupItems().forEach { item ->
            actionRow(
                item.title,
                item.subtitle,
                if (item.granted) getString(R.string.granted) else getString(R.string.grant)
            ) { openSetupItem(item) }
        }

        section("Floating mic")
        switchRow(
            "Floating mic button",
            "Overlay permission ke baad app ke upar chhota mic dikhega.",
            Prefs.floatingMic
        ) { on ->
            Prefs.floatingMic = on
            if (on && !permissions.overlay()) {
                permissions.openOverlaySettings()
                toast("Overlay permission do, phir wapas aao.")
            }
        }

        section("Data")
        actionRow(
            "Clear notes",
            "Saare saved notes hata do.",
            "Clear"
        ) {
            com.dark.assistant.data.NotesStore.clear(this)
            toast("Notes clear")
        }
        actionRow(
            "Clear chat history",
            "Transcript delete kar do.",
            "Clear"
        ) {
            com.dark.assistant.engine.History.clear(this)
            toast("Chat clear")
        }
        actionRow(
            "Reset all settings",
            "Sab preferences default par.",
            "Reset"
        ) {
            Prefs.clearAll()
            rebuild()
            toast("Settings reset")
        }

        section("About")
        actionRow(
            getString(R.string.app_name),
            "v1.0.0 — on-device, offline rule engine. Koi data server par nahi jaata.",
            ""
        ) {
            AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setMessage(
                    getString(R.string.settings_about_body) +
                        "\n\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE}"
                )
                .setPositiveButton(R.string.ok, null)
                .show()
        }
    }

    private fun openSetupItem(item: PermissionGate.SetupItem) {
        when (item.kind) {
            PermissionGate.Kind.ACCESSIBILITY -> permissions.openAccessibilitySettings()
            PermissionGate.Kind.NOTIFICATION_ACCESS -> permissions.openNotificationAccessSettings()
            PermissionGate.Kind.OVERLAY -> permissions.openOverlaySettings()
            PermissionGate.Kind.BATTERY -> DeviceControl.requestIgnoreBatteryOptimizations(this)
            PermissionGate.Kind.RUNTIME -> {
                // Kick the user to the app's own permission page; runtime prompts
                // are driven from the chat screen setup sheet.
                try {
                    val i = Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:$packageName")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (_: Throwable) { }
            }
        }
    }

    // ------------------------------------------------------------- row types

    private fun section(title: String) {
        val tv = TextView(this).apply {
            text = title
            setTextAppearance(R.style.DA_SectionLabel)
            setPadding(0, dp(20), 0, dp(8))
        }
        container.addView(tv)
    }

    private fun switchRow(
        title: String,
        subtitle: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ) {
        val row = layoutInflater.inflate(R.layout.item_setting_switch, container, false)
        row.findViewById<TextView>(R.id.title).text = title
        row.findViewById<TextView>(R.id.subtitle).text = subtitle
        val toggle = row.findViewById<MaterialSwitch>(R.id.toggle)
        toggle.isChecked = checked
        toggle.setOnCheckedChangeListener { _, value -> onChange(value) }
        container.addView(row)
    }

    private fun actionRow(
        title: String,
        subtitle: String,
        status: String,
        onClick: () -> Unit
    ) {
        val row = layoutInflater.inflate(R.layout.item_setting_action, container, false)
        row.findViewById<TextView>(R.id.title).text = title
        row.findViewById<TextView>(R.id.subtitle).text = subtitle
        val statusView = row.findViewById<TextView>(R.id.status)
        statusView.text = status
        statusView.visibility = if (status.isEmpty()) View.GONE else View.VISIBLE
        row.setOnClickListener { onClick() }
        container.addView(row)
    }

    private fun pickerRow(title: String, subtitle: String, onClick: () -> Unit) {
        actionRow(title, subtitle, "›", onClick)
    }

    private fun sliderRow(
        title: String,
        valueLabel: String,
        value: Float,
        min: Float,
        max: Float,
        onChange: (Float) -> Unit
    ) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(androidx.core.content.ContextCompat.getColor(this@SettingsActivity, R.color.da_surface))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val label = TextView(this).apply {
            text = "$title  ($valueLabel)"
            setTextColor(androidx.core.content.ContextCompat.getColor(this@SettingsActivity, R.color.da_text))
            textSize = 15f
        }
        val slider = Slider(this).apply {
            this.valueFrom = min
            this.valueTo = max
            this.stepSize = 0.1f
            this.value = value
        }
        slider.addOnChangeListener { _, v, fromUser ->
            if (fromUser) {
                label.text = "$title  (${"%.1f".format(v)}x)"
                onChange(v)
            }
        }
        wrap.addView(label)
        wrap.addView(slider)
        container.addView(wrap)
    }

    private fun languageLabel(tag: String): String = when (tag) {
        "hi-IN" -> "हिंदी (hi-IN)"
        "en-IN" -> "English (en-IN)"
        else -> "English (en-US)"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
