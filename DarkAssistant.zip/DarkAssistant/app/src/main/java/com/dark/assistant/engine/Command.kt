package com.dark.assistant.engine

/**
 * Everything the assistant can actually do on the device. Each variant maps to
 * one executor function; nothing here is simulated.
 */
sealed class Command {

    // --- Apps & navigation -------------------------------------------------
    data class OpenApp(val app: String) : Command()
    data class OpenUrl(val url: String) : Command()
    data class SearchWeb(val query: String) : Command()
    data class SearchYoutube(val query: String) : Command()
    data class PlayMusic(val query: String) : Command()
    data class Navigate(val place: String) : Command()
    data class OpenSettings(val screen: String) : Command()

    // --- Communication ----------------------------------------------------
    data class Call(val contact: String, val speaker: Boolean) : Command()
    data class AnswerCall(val accept: Boolean) : Command()
    data class SendSms(val contact: String, val message: String) : Command()
    data class SendWhatsapp(val contact: String, val message: String?) : Command()
    data class WhatsappCall(val contact: String) : Command()

    // --- Hardware switches ------------------------------------------------
    data class Torch(val on: Boolean) : Command()
    data object ToggleTorchAgain : Command()
    data class Wifi(val on: Boolean) : Command()
    data class Bluetooth(val on: Boolean) : Command()
    data class Airplane(val on: Boolean) : Command()
    data class Hotspot(val on: Boolean) : Command()
    data class Ringer(val mode: RingerMode) : Command()
    data class Dnd(val on: Boolean) : Command()
    data class BatterySaver(val on: Boolean) : Command()

    // --- Audio ------------------------------------------------------------
    data class Volume(val level: Int) : Command()
    data class VolumeStep(val up: Boolean) : Command()
    data class Mute(val mute: Boolean) : Command()

    // --- Time / alarms ----------------------------------------------------
    data class SetAlarm(val hour: Int, val minute: Int, val label: String?) : Command()
    data class SetTimer(val seconds: Int) : Command()
    data class ShowAlarms : Command()

    // --- Screen control (needs Accessibility) -----------------------------
    data object GoBack : Command()
    data object GoHome : Command()
    data object ShowRecents : Command()
    data object ShowNotifications : Command()
    data object QuickSettings : Command()
    data object LockScreen : Command()
    data object TakeScreenshot : Command()
    data object ReadScreen : Command()
    data object ClearNotifications : Command()
    data class TapText(val text: String) : Command()
    data class Scroll(val forward: Boolean) : Command()
    data class TypeText(val text: String) : Command()
    data class PressKey(val key: KeyName) : Command()

    // --- Information ------------------------------------------------------
    data object BatteryStatus : Command()
    data object TimeNow : Command()
    data object DateToday : Command()
    data object DeviceInfo : Command()
    data class Weather(val city: String?) : Command()
    data class Calculate(val expression: String) : Command()

    // --- Notes (stored locally) -------------------------------------------
    data class SaveNote(val text: String) : Command()
    data object ReadNotes : Command()
    data object ClearNotes : Command()

    // --- Assistant meta ---------------------------------------------------
    data class Say(val text: String) : Command()
    data object Stop : Command()
    data object Help : Command()
    data class Unknown(val raw: String) : Command()
}

enum class RingerMode { SILENT, VIBRATE, NORMAL }

enum class KeyName { ENTER, BACKSPACE, DELETE, TAB, SPACE, ESCAPE, SEARCH }
