package com.dark.assistant.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dark.assistant.R
import com.dark.assistant.data.ChatStore

/** Chat bubbles: user on the right, assistant on the left. */
class ChatAdapter(
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<ChatAdapter.Holder>() {

    private val items = mutableListOf<ChatStore.Message>()

    fun submit(list: List<ChatStore.Message>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun add(message: ChatStore.Message): Int {
        items.add(message)
        notifyItemInserted(items.size - 1)
        return items.size - 1
    }

    fun update(index: Int, text: String) {
        if (index !in items.indices) return
        items[index] = items[index].copy(text = text)
        notifyItemChanged(index)
    }

    fun all(): List<ChatStore.Message> = items.toList()

    fun clear() {
        val size = items.size
        items.clear()
        notifyItemRangeRemoved(0, size)
    }

    override fun getItemViewType(position: Int): Int = if (items[position].fromUser) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val layout = if (viewType == 1) R.layout.item_chat_user else R.layout.item_chat_bot
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.bubble.text = item.text
        holder.bubble.setOnClickListener { onClick(item.text) }
    }

    override fun getItemCount(): Int = items.size

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val bubble: TextView = view.findViewById(R.id.bubble)
    }
}
