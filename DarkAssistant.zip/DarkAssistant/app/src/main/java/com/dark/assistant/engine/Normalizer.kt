package com.dark.assistant.engine

/**
 * Turns messy speech-to-text output into something the rule engine can match.
 *
 * Voice input for Hindi usually arrives in Devanagari, while typed input is
 * Roman (Hinglish). Both forms are folded onto one Roman keyword space so the
 * same rules work either way.
 */
object Normalizer {

    /** Devanagari word -> roman keyword. Covers the words people actually use. */
    private val DEVANAGARI = mapOf(
        "खोलो" to "kholo", "खोल" to "khol", "खोलना" to "kholna", "चालू" to "chalu",
        "बंद" to "band", "करो" to "karo", "कर" to "kar", "करना" to "karna",
        "दो" to "do", "दीजिए" to "kijiye", "डालो" to "dalo", "लगाओ" to "lagao",
        "बजाओ" to "bajao", "चलाओ" to "chalao", "रोको" to "roko", "रुको" to "ruko",
        "टॉर्च" to "torch", "टार्च" to "torch", "फ्लैश" to "flash", "लाइट" to "light",
        "कैमरा" to "camera", "फोन" to "phone", "कॉल" to "call", "काल" to "call",
        "मैसेज" to "message", "संदेश" to "message", "भेजो" to "bhejo",
        "भेज" to "bhej", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "गाना" to "gana", "गाने" to "gane", "संगीत" to "music", "म्यूजिक" to "music",
        "आवाज़" to "awaz", "आवाज" to "awaz", "वॉल्यूम" to "volume", "तेज़" to "tez",
        "तेज" to "tez", "धीमा" to "dhima", "धीमी" to "dhimi", "बढ़ाओ" to "badhao",
        "कम" to "kam", "ज्यादा" to "zyada", "शांत" to "shant",
        "साइलेंट" to "silent", "साइलेन्ट" to "silent", "वाइब्रेशन" to "vibration",
        "अलार्म" to "alarm", "टाइमर" to "timer", "सेट" to "set", "समय" to "samay",
        "कितना" to "kitna", "कितने" to "kitne", "बजे" to "baje", "बजा" to "baja",
        "मिनट" to "minute", "मिनिट" to "minute", "घंटा" to "ghanta", "घंटे" to "ghante",
        "सेकंड" to "second", "स्क्रीन" to "screen", "स्क्रीनशॉट" to "screenshot",
        "फोटो" to "photo", "तस्वीर" to "photo", "होम" to "home", "वापस" to "wapas",
        "पीछे" to "piche", "आगे" to "aage", "हाँ" to "haan", "हां" to "haan",
        "नहीं" to "nahi", "नही" to "nahi", "नोट" to "note", "नोट्स" to "notes",
        "लिखो" to "likho", "लिख" to "likh", "याद" to "yaad", "रखो" to "rakho",
        "क्या" to "kya", "कैसे" to "kaise", "कहाँ" to "kahan", "कौन" to "kaun",
        "मौसम" to "mausam", "बैटरी" to "battery", "चार्ज" to "charge",
        "प्रतिशत" to "percent", "ऐप" to "app", "एप" to "app", "ऍप" to "app",
        "वाईफाई" to "wifi", "वाई-फाई" to "wifi", "ब्लूटूथ" to "bluetooth",
        "डेटा" to "data", "हॉटस्पॉट" to "hotspot", "एयरप्लेन" to "airplane",
        "उड़ान" to "udan", "मोड" to "mode", "हेल्प" to "help", "मदद" to "madad",
        "नमस्ते" to "namaste", "धन्यवाद" to "dhanyavad", "शुक्रिया" to "shukriya",
        "बताओ" to "batao", "बता" to "bata", "सुनाओ" to "sunao", "सुनो" to "suno",
        "पढ़ो" to "padho", "पढ़" to "padh", "दिखाओ" to "dikhao", "दिखा" to "dikha",
        "कैलेंडर" to "calendar", "कांटेक्ट" to "contact", "संपर्क" to "contact",
        "इंटरनेट" to "internet", "लॉक" to "lock", "अनलॉक" to "unlock",
        "चमक" to "chamak", "रोशनी" to "roshni", "कॉपी" to "copy",
        "पेस्ट" to "paste", "टाइप" to "type", "सर्च" to "search", "ढूंढो" to "dhoondo",
        "जाना" to "jana", "जाओ" to "jao", "रास्ता" to "rasta", "मैप" to "map",
        "एक" to "ek", "दो" to "do", "तीन" to "teen", "चार" to "char", "पांच" to "panch",
        "छह" to "chhah", "सात" to "saat", "आठ" to "aath", "नौ" to "nau", "दस" to "das",
        "बीस" to "bees", "तीस" to "tees", "चालीस" to "chalees", "पचास" to "pachas",
        "साठ" to "saath", "सत्तर" to "sattar", "अस्सी" to "assi", "नब्बे" to "nabbe",
        "सौ" to "sau", "आधा" to "aadha", "सुबह" to "subah", "शाम" to "shaam",
        "रात" to "raat", "दोपहर" to "dopahar", "आज" to "aaj", "कल" to "kal",
        "अभी" to "abhi", "फिर" to "phir", "और" to "aur", "पर" to "par", "से" to "se",
        "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "में" to "me",
        "मेरा" to "mera", "मेरी" to "meri", "मुझे" to "mujhe", "मैं" to "main",
        "तुम" to "tum", "आप" to "aap", "ये" to "ye", "वो" to "wo", "है" to "hai",
        "हो" to "ho", "गया" to "gaya", "गयी" to "gayi", "हुआ" to "hua"
    )

    /** Roman number words -> value. Short list kept deliberately simple. */
    private val NUMBER_WORDS = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10,
        "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
        "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18,
        "nineteen" to 19, "twenty" to 20, "thirty" to 30, "forty" to 40,
        "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90,
        "ek" to 1, "do" to 2, "teen" to 3, "char" to 4, "panch" to 5, "paanch" to 5,
        "chhah" to 6, "che" to 6, "chhe" to 6, "saat" to 7, "aath" to 8, "nau" to 9,
        "das" to 10, "bees" to 20, "tees" to 30, "chalees" to 40, "pachas" to 50,
        "saath" to 60, "sattar" to 70, "assi" to 80, "nabbe" to 90
    )

    private val FILLER_ENDINGS = listOf(
        "kar do", "kar de", "kar dena", "kardo", "kro", "karo", "kijiye", "kijiyega",
        "please", "plz", "zara", "kripya", "dena", "de do", "dijiye"
    )

    fun normalize(input: String): String {
        var s = input.lowercase().trim()
        if (s.isEmpty()) return s

        // Devanagari digits -> ASCII
        s = s.map { ch ->
            if (ch in '\u0966'..'\u096F') ('0' + (ch - '\u0966')) else ch
        }.joinToString("")

        // Word-by-word Devanagari transliteration, keeping unknown words.
        s = s.split(' ', '\n', '\t').joinToString(" ") { word ->
            val key = word.trim(' ', ',', '.', '?', '!', '"', '\'', ';', ':')
            DEVANAGARI[key] ?: word
        }

        // Strip punctuation but keep maths symbols and time colons.
        s = s.replace(Regex("[^a-z0-9%+\\-*/x×÷.:\\s]"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        return s
    }

    /** Removes trailing politeness so "torch on karo" and "torch on" match. */
    fun stripFillers(s: String): String {
        var out = s
        var changed = true
        while (changed) {
            changed = false
            for (f in FILLER_ENDINGS) {
                if (out.endsWith(" $f")) {
                    out = out.dropLast(f.length + 1).trim()
                    changed = true
                }
            }
        }
        return out
    }

    /** Converts "paanch"/"five" to digits; handles "twenty five". */
    fun wordsToDigits(s: String): String {
        val words = s.split(' ')
        val out = mutableListOf<String>()
        var i = 0
        while (i < words.size) {
            val a = NUMBER_WORDS[words[i]]
            if (a == null) {
                out.add(words[i]); i++; continue
            }
            var value = a
            var used = 1
            if (i + 1 < words.size) {
                val b = NUMBER_WORDS[words[i + 1]]
                if (b != null && b < 10 && a >= 20 && a % 10 == 0) {
                    value = a + b
                    used = 2
                }
            }
            out.add(value.toString())
            i += used
        }
        return out.joinToString(" ")
    }

    /** Extracts the first integer in a string, if any. */
    fun firstInt(s: String): Int? = Regex("\\d+").find(s)?.value?.toIntOrNull()

    /**
     * Pulls a contact name out of Hinglish phrasing.
     * "amit ko call karo" -> "amit"; "call amit" -> "amit".
     */
    fun extractContact(s: String, verbs: List<String>): String? {
        // Pattern: <name> ko <verb...>
        val koPattern = Regex("^(.*?)\\s+ko\\s+(?:.*)$")
        for (verb in verbs) {
            val ko = Regex("^(.*?)\\s+ko\\s+(?:$verb)")
            val m = ko.find(s)
            if (m != null) return cleanName(m.groupValues[1], verbs)
        }
        // Pattern: <verb> <name>
        for (verb in verbs) {
            val direct = Regex("(?:^|\\s)$verb\\s+(?:to\\s+|se\\s+)?(.*)$")
            val m = direct.find(s)
            if (m != null) {
                val name = cleanName(m.groupValues[1], verbs)
                if (name.isNotEmpty()) return name
            }
        }
        koPattern.find(s)?.let { }
        return null
    }

    private fun cleanName(raw: String, verbs: List<String>): String {
        var n = raw
        for (v in listOf("phone", "call", "message", "msg", "whatsapp", "ko", "par", "pe", "se", "please", "zara")) {
            n = n.replace(Regex("(^|\\s)$v(\\s|$)"), " ")
        }
        for (v in verbs) n = n.replace(Regex(v), " ")
        n = n.replace(Regex("\\s+"), " ").trim()
        n = n.removePrefix("mera ").removePrefix("meri ").removePrefix("my ")
        return n
    }

    /**
     * Parses times: "7 baje", "7:30", "shaam 7 baje", "saat baje", "19:45".
     * Returns hour/minute in 24h form.
     */
    fun parseTime(s: String): Pair<Int, Int>? {
        val text = wordsToDigits(s)
        val colon = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(text)
        if (colon != null) {
            var h = colon.groupValues[1].toInt()
            val m = colon.groupValues[2].toInt()
            if (h in 0..23 && m in 0..59) return applyAmPm(h, m, text)
        }
        val baje = Regex("(\\d{1,2})(?:\\s*baje)?(?:\\s*(\\d{1,2}))?").find(text)
        val m1 = Regex("(\\d{1,2})\\s*(?:baje|baja|o.?clock|oclock|am|pm|hours?)").find(text)
        if (m1 != null) {
            val h = m1.groupValues[1].toIntOrNull() ?: return null
            if (h !in 0..23) return null
            val mins = Regex("(?:baje|baja)\\s*(\\d{1,2})").find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val half = text.contains("aadha") || text.contains("half past")
            return applyAmPm(h, if (half) 30 else mins.coerceIn(0, 59), text)
        }
        if (baje != null) {
            val h = baje.groupValues[1].toIntOrNull() ?: return null
            if (h in 0..23) {
                val mins = baje.groupValues[2].toIntOrNull() ?: 0
                return applyAmPm(h, mins.coerceIn(0, 59), text)
            }
        }
        return null
    }

    private fun applyAmPm(hour: Int, minute: Int, text: String): Pair<Int, Int> {
        var h = hour
        val pm = text.contains("pm") || text.contains("shaam") || text.contains("raat") ||
            text.contains("dopahar") || text.contains("evening") || text.contains("night")
        val am = text.contains("am") || text.contains("subah") || text.contains("morning")
        if (pm && h in 1..11) h += 12
        if (am && h == 12) h = 0
        if (!pm && !am && h in 1..6) h += 12 // "7 baje" at night is the common intent
        return h.coerceIn(0, 23) to minute.coerceIn(0, 59)
    }

    /** "5 minute", "10 second", "1 ghanta" -> total seconds. */
    fun parseDurationSeconds(s: String): Int? {
        val text = wordsToDigits(s)
        val re = Regex("(\\d{1,3})\\s*(second|sec|minute|min|ghanta|ghante|hour|hr)")
        val m = re.find(text) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        return when (m.groupValues[2]) {
            "second", "sec" -> n
            "minute", "min" -> n * 60
            else -> n * 3600
        }
    }
}
