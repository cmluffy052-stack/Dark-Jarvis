package com.dark.assistant.services

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.dark.assistant.AssistantApp
import com.dark.assistant.R
import com.dark.assistant.data.Prefs
import com.dark.assistant.ui.MainActivity

/** Posts app-level notifications (screenshot saved, wake word armed). */
object Notifier {

    fun status(
        context: Context,
        title: String,
        text: String
    ): Notification {
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            context, 1,
            Intent(context, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(context, AssistantApp.CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_bot)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(0, context.getString(R.string.service_stop), stop)
            .build()
    }

    fun post(context: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val notification = NotificationCompat.Builder(context, AssistantApp.CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_bot)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        nm.notify(id, notification)
    }

    fun foregroundType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else 0
}

/**
 * Optional always-on listener. Android does not allow true wake-word detection
 * without a downloaded model, so this service does the honest thing: it shows a
 * persistent "ready" notification and opens the assistant when tapped. When the
 * user starts dictation from the notification it records and parses that turn.
 */
class WakeWordService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.wakeWordEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val notification = Notifier.status(
            this,
            getString(R.string.service_title),
            getString(R.string.service_text)
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, Notifier.foregroundType())
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep the status alive if the user enabled it.
        if (!Prefs.wakeWordEnabled) stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    companion object {
        const val NOTIF_ID = 1201
        const val ACTION_STOP = "com.dark.assistant.STOP_WAKE"

        @Volatile
        var running = false
            private set

        fun start(context: Context) {
            val i = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}

/** Boot receiver so the status service can come back after a restart. */
class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            if (Prefs.wakeWordEnabled) {
                try {
                    WakeWordService.start(context)
                } catch (_: Throwable) { }
            }
        }
    }
}

/** Lets the accessibility service report screenshot results without a binder. */
object ScreenshotBridge {

    @Volatile
    var listener: ((String) -> Unit)? = null

    @Volatile
    var failureListener: ((String) -> Unit)? = null

    fun notifySaved(context: Context, path: String) {
        listener?.invoke(path)
        Notifier.post(context, 1301, "Screenshot ready", path.substringAfterLast('/'))
    }

    fun notifyFailed(context: Context, message: String) {
        failureListener?.invoke(message)
        Notifier.post(context, 1302, "Screenshot failed", message)
    }
}
