package com.dark.assistant.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.dark.assistant.engine.KeyName
import com.dark.assistant.engine.ScreenControl
import java.io.File
import java.io.FileOutputStream

/**
 * The real "control the phone" piece.
 *
 * Android only lets an app press system buttons / read the screen through an
 * AccessibilityService. That is the same mechanism every automation app uses.
 * Everything here happens locally; no screen content leaves the device.
 */
class ControlAccessibilityService : AccessibilityService(), ScreenControl {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // Ask for every signal we can legally read, including the ability to
        // capture the screen and read windows.
        serviceInfo = serviceInfo?.apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = 100
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (pkg != null && pkg != packageName) lastForegroundPackage = pkg
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    override fun isConnected(): Boolean = true

    // ------------------------------------------------------------ navigation

    override fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    override fun home() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun recents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    override fun openNotifications() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    override fun openQuickSettings() {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    override fun lockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            // Pre-Pie has no lock action; open the power menu instead.
            performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        }
    }

    override fun foregroundApp(): String? = lastForegroundPackage

    // ---------------------------------------------------------- screen text

    override fun readScreen(onText: (String) -> Unit) {
        val root = rootInActiveWindow
        if (root == null) {
            onText("Screen padhne ke liye koi window nahi mili.")
            return
        }
        val chunks = LinkedHashSet<String>()
        collectText(root, chunks, 0)
        root.recycle()
        val text = chunks.joinToString("\n").trim()
        onText(if (text.isEmpty()) "Is screen par koi readable text nahi hai." else text.take(4000))
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (node == null || depth > 60) return
        node.text?.toString()?.trim()?.let { if (it.isNotEmpty()) out.add(it) }
        node.contentDescription?.toString()?.trim()?.let { if (it.isNotEmpty()) out.add(it) }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out, depth + 1)
            child.recycle()
        }
    }

    // ----------------------------------------------------------- screenshot

    override fun screenshot(onSaved: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onSaved("")
            notifyScreenshotFailed("Screenshot ke liye Android 11 (API 30) ya upar chahiye.")
            return
        }
        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val bmp = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    result.hardwareBuffer.close()
                    if (bmp == null) {
                        notifyScreenshotFailed("Screenshot bitmap nahi bana.")
                        onSaved("")
                        return
                    }
                    val path = saveBitmap(bmp)
                    bmp.recycle()
                    onSaved(path)
                    ScreenshotBridge.notifySaved(this@ControlAccessibilityService, path)
                }

                override fun onFailure(errorCode: Int) {
                    onSaved("")
                    notifyScreenshotFailed("Screenshot fail ho gaya (code $errorCode). Screenshots OS-level block ho sakte hain.")
                }
            }
        )
    }

    private fun notifyScreenshotFailed(message: String) {
        ScreenshotBridge.notifyFailed(this, message)
    }

    private fun saveBitmap(bitmap: Bitmap): String {
        val dir = File(getExternalFilesDir("Screenshots") ?: filesDir, "")
        if (!dir.exists()) dir.mkdirs()
        val name = "dark_${System.currentTimeMillis()}.png"
        val file = File(dir, name)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        android.media.MediaScannerConnection.scanFile(
            this, arrayOf(file.absolutePath), arrayOf("image/png"), null
        )
        return file.absolutePath
    }

    // ------------------------------------------------------------- gestures

    override fun tapText(text: String) {
        val root = rootInActiveWindow ?: throw IllegalStateException("No active window")
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        findByText(root, text.lowercase(), nodes, 0)
        val target = nodes.firstOrNull()
            ?: throw IllegalStateException("\"$text\" screen par nahi mila")
        var clickable: AccessibilityNodeInfo? = target
        while (clickable != null && !clickable.isClickable) clickable = clickable.parent
        val ok = clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        root.recycle()
        if (!ok) throw IllegalStateException("\"$text\" click nahi ho paya")
    }

    private fun findByText(
        node: AccessibilityNodeInfo?,
        needle: String,
        out: MutableList<AccessibilityNodeInfo>,
        depth: Int
    ) {
        if (node == null || depth > 60) return
        val label = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").lowercase()
        if (label.contains(needle)) out.add(node)
        for (i in 0 until node.childCount) {
            findByText(node.getChild(i), needle, out, depth + 1)
        }
    }

    override fun scroll(forward: Boolean) {
        val root = rootInActiveWindow ?: throw IllegalStateException("No window")
        val scrollable = findScrollable(root)
        if (scrollable == null) {
            // Fall back to a swipe gesture in the middle of the screen.
            val dm = resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val path = android.graphics.Path()
            val startY = if (forward) (h * 0.75f) else (h * 0.25f)
            val endY = if (forward) (h * 0.25f) else (h * 0.75f)
            path.moveTo(w / 2f, startY)
            path.lineTo(w / 2f, endY)
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 260))
                .build()
            dispatchGesture(gesture, null, null)
            return
        }
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        scrollable.performAction(action)
        root.recycle()
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    override fun typeText(text: String) {
        val root = rootInActiveWindow ?: throw IllegalStateException("No window")
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: throw IllegalStateException("Koi input field focus mein nahi hai")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        root.recycle()
    }

    override fun pressKey(key: KeyName) {
        val action = when (key) {
            KeyName.ENTER -> AccessibilityNodeInfo.ACTION_IME_ENTER
            KeyName.BACKSPACE -> AccessibilityNodeInfo.ACTION_CLEAR_FOCUS
            else -> null
        }
        val root = rootInActiveWindow ?: throw IllegalStateException("No window")
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (action != null && focused != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            focused.performAction(action)
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        root.recycle()
    }

    companion object {
        @Volatile
        var instance: ControlAccessibilityService? = null
            private set

        @Volatile
        var lastForegroundPackage: String? = null

        fun isRunning(): Boolean = instance != null
    }
}
