package com.dark.assistant.services

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.dark.assistant.data.Prefs

/**
 * Optional: reads incoming notifications and hands them to the assistant so it
 * can read them aloud. Only active when the user enables "Announce
 * notifications" in Settings and grants notification access.
 */
class NotificationWatcher : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!Prefs.announceNotifications) return
        if (sbn.packageName == packageName) return

        val n = sbn.notification ?: return
        // Skip ongoing / silent / group summaries — those are noise.
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val body = big.ifEmpty { text }
        if (title.isEmpty() && body.isEmpty()) return

        val appLabel = try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Throwable) {
            sbn.packageName
        }

        // Ignore media-style notifications that repeat constantly.
        if (n.category == Notification.CATEGORY_TRANSPORT) return

        lastEvent = EventArgs(appLabel, title, body, System.currentTimeMillis())
        listener?.invoke(lastEvent!!)
    }

    data class EventArgs(
        val app: String,
        val title: String,
        val text: String,
        val at: Long
    )

    companion object {
        @Volatile
        var connected = false
            private set

        @Volatile
        var listener: ((EventArgs) -> Unit)? = null

        @Volatile
        var lastEvent: EventArgs? = null
    }
}
