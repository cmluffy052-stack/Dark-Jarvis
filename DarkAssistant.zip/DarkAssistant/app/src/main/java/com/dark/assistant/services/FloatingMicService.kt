package com.dark.assistant.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.dark.assistant.R
import com.dark.assistant.data.Prefs
import com.dark.assistant.ui.MainActivity

/**
 * Optional floating mic: a draggable bubble that sits over every app.
 *
 * Tapping it opens the assistant ready to listen. It needs the "display over
 * other apps" permission, which the Settings screen sends the user to grant.
 */
class FloatingMicService : Service() {

    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        startForegroundCompat()
        showBubble()
    }

    private fun startForegroundCompat() {
        val notification = Notifier.status(
            this,
            getString(R.string.assistant_name),
            "Floating mic active hai"
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIF_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, notification)
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (_: Throwable) { }
    }

    private fun showBubble() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 320
        }

        val view = LayoutInflater.from(this).inflate(R.layout.view_float_mic, null)
        bubble = view

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { wm.updateViewLayout(view, params) } catch (_: Throwable) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) launchAssistant()
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(view, params)
        } catch (_: Throwable) {
            stopSelf()
        }
    }

    private fun launchAssistant() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
                    .putExtra(MainActivity.EXTRA_START_LISTENING, true)
            )
        } catch (_: Throwable) { }
    }

    override fun onDestroy() {
        bubble?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Throwable) { }
        }
        bubble = null
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID = 1401

        fun refresh(context: Context) {
            val shouldRun = Prefs.floatingMic && Settings.canDrawOverlays(context)
            val intent = Intent(context, FloatingMicService::class.java)
            if (shouldRun) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } else {
                context.stopService(intent)
            }
        }
    }
}
