package com.dark.assistant.engine

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * Contact lookup + call/SMS/WhatsApp intents. Names are matched against the
 * phone's own contact list, so "mummy ko call" needs a contact saved as
 * "Mummy" (or with "mummy" in the display name / nickname).
 */
object CommsControl {

    data class Contact(val name: String, val number: String)

    fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun canCall(context: Context) = hasPermission(context, Manifest.permission.CALL_PHONE)
    fun canReadContacts(context: Context) = hasPermission(context, Manifest.permission.READ_CONTACTS)
    fun canSms(context: Context) = hasPermission(context, Manifest.permission.SEND_SMS)

    /** Finds the best contact match for a spoken name. */
    fun findContact(context: Context, spoken: String): Contact? {
        if (!canReadContacts(context)) return null
        val query = spoken.trim()
        if (query.isEmpty()) return null

        val uri = Uri.withAppendedPath(
            ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
            Uri.encode(query)
        )
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        val results = mutableListOf<Contact>()
        try {
            context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
                val nameIdx = c.getColumnIndex(projection[0])
                val numIdx = c.getColumnIndex(projection[1])
                while (c.moveToNext() && results.size < 10) {
                    val name = c.getString(nameIdx) ?: continue
                    val num = c.getString(numIdx) ?: continue
                    results.add(Contact(name, num.replace(Regex("\\s+"), "")))
                }
            }
        } catch (_: Throwable) { }

        if (results.isEmpty()) return null

        // Prefer an exact/starts-with match over whatever the provider returned first.
        val lower = query.lowercase()
        return results.firstOrNull { it.name.lowercase() == lower }
            ?: results.firstOrNull { it.name.lowercase().startsWith(lower) }
            ?: results.firstOrNull { it.name.lowercase().contains(lower) }
            ?: results.first()
    }

    /** Places a call (needs CALL_PHONE) or opens the dialer pre-filled. */
    fun call(context: Context, spoken: String, useSpeaker: Boolean = false): Result {
        val contact = findContact(context, spoken)
        val number = contact?.number ?: digitsOnly(spoken)

        if (number == null) {
            return if (!canReadContacts(context)) {
                Result(false, "Contacts ki permission nahi hai, isliye \"$spoken\" ko dhoondh nahi paya.")
            } else {
                Result(false, "\"$spoken\" naam ka contact nahi mila.")
            }
        }

        val label = contact?.name ?: number
        return try {
            if (canCall(context)) {
                val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (useSpeaker) i.putExtra("android.telecom.extra.START_CALL_WITH_SPEAKERPHONE", true)
                context.startActivity(i)
                Result(true, "$label ko call lag raha hai.")
            } else {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                Result(true, "$label ka dialer khol diya — call button dabao. (CALL_PHONE permission doge to main khud laga dunga.)")
            }
        } catch (e: Throwable) {
            Result(false, "Call nahi lag paya: ${e.message}")
        }
    }

    fun sendSms(context: Context, spoken: String, message: String): Result {
        val contact = findContact(context, spoken)
        val number = contact?.number ?: digitsOnly(spoken)
        if (number == null) {
            return Result(false, "\"$spoken\" ka number nahi mila.")
        }
        val label = contact?.name ?: number
        if (message.isBlank()) {
            return openSmsComposer(context, number, label, "")
        }
        if (!canSms(context)) {
            val r = openSmsComposer(context, number, label, message)
            return Result(r.ok, "${r.message} (SMS permission nahi hai isliye maine message likh diya — send dabao.)")
        }
        return try {
            val sms = android.telephony.SmsManager.getDefault()
            val parts = sms.divideMessage(message)
            if (parts.size > 1) {
                sms.sendMultipartTextMessage(number, null, parts, null, null)
            } else {
                sms.sendTextMessage(number, null, message, null, null)
            }
            Result(true, "$label ko SMS bhej diya: \"$message\"")
        } catch (e: Throwable) {
            val r = openSmsComposer(context, number, label, message)
            Result(r.ok, "${r.message} SMS direct nahi gaya: ${e.message}")
        }
    }

    private fun openSmsComposer(context: Context, number: String, label: String, body: String): Result {
        return try {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (body.isNotEmpty()) i.putExtra("sms_body", body)
            context.startActivity(i)
            Result(true, "Message app mein $label ka draft khol diya.")
        } catch (e: Throwable) {
            Result(false, "Message app nahi khula.")
        }
    }

    /** WhatsApp chat / call deep links. No permission needed. */
    fun whatsapp(context: Context, spoken: String, message: String?): Result {
        val contact = findContact(context, spoken)
        val raw = contact?.number ?: digitsOnly(spoken)
        if (raw == null) return Result(false, "\"$spoken\" ka number nahi mila.")

        val wa = normalizeForWhatsApp(raw) ?: return Result(false, "WhatsApp ke liye number sahi nahi lag raha.")
        val label = contact?.name ?: raw

        return if (message.isNullOrBlank()) {
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$wa"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Result(true, "$label ki WhatsApp chat khol di.")
            } catch (e: Throwable) {
                Result(false, "WhatsApp installed nahi hai?")
            }
        } else {
            try {
                val i = Intent(Intent.ACTION_SEND).apply {
                    setPackage("com.whatsapp")
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    putExtra("jid", "$wa@s.whatsapp.net")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(i)
                Result(true, "$label ko WhatsApp message taiyaar hai: \"$message\" — send dabao.")
            } catch (e: Throwable) {
                // Fall back to the web deep link with prefilled text.
                try {
                    context.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://wa.me/$wa?text=${Uri.encode(message)}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    Result(true, "$label ki chat message ke saath khol di.")
                } catch (e2: Throwable) {
                    Result(false, "WhatsApp se message nahi ja paya.")
                }
            }
        }
    }

    fun whatsappCall(context: Context, spoken: String): Result {
        val contact = findContact(context, spoken)
        val raw = contact?.number ?: digitsOnly(spoken)
        if (raw == null) return Result(false, "\"$spoken\" ka number nahi mila.")
        val wa = normalizeForWhatsApp(raw) ?: return Result(false, "Number sahi nahi lag raha.")
        val label = contact?.name ?: raw
        // WhatsApp has no public "call" intent; the chat screen has the call button.
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$wa"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Result(true, "$label ki WhatsApp chat khol di. Call button wahan hai — ya bolo \"$label ko phone karo\".")
        } catch (e: Throwable) {
            Result(false, "WhatsApp nahi khula.")
        }
    }

    /** Digits only, or null when the text has no plausible phone number. */
    fun digitsOnly(text: String): String? {
        val cleaned = text.replace(Regex("[^0-9+]"), "")
        val digits = cleaned.replace("+", "")
        if (digits.length < 3) return null
        // Short strings like "100" are fine (emergency), but "7" is not a number.
        return if (digits.length <= 3) cleaned else cleaned
    }

    /** "+91 98765 43210" -> "919876543210" for the wa.me link. */
    fun normalizeForWhatsApp(raw: String): String? {
        var d = raw.replace(Regex("[^0-9]"), "")
        if (d.length == 10) d = "91$d"
        if (d.length < 10 || d.length > 15) return null
        return d
    }

    fun openDialer(context: Context): Result {
        return try {
            context.startActivity(
                Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Result(true, "Dialer khol diya.")
        } catch (e: Throwable) {
            Result(false, "Dialer nahi mila.")
        }
    }
}
