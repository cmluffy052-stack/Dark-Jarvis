package com.dark.assistant.engine

import android.Manifest
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.dark.assistant.data.Prefs

/**
 * Hardware and system switches. Where Android forbids a silent change (Wi-Fi,
 * Bluetooth, airplane mode on newer releases) we open the exact system panel
 * and report that a tap is needed, instead of pretending it worked.
 */
object DeviceControl {

    // ---------------------------------------------------------------- torch

    fun setTorch(context: Context, on: Boolean): Result {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { camId ->
                cm.getCameraCharacteristics(camId)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Result(false, "Is phone mein flashlight nahi mila.")
            cm.setTorchMode(id, on)
            Prefs.torchOn = on
            Result(true, if (on) "Torch on kar di." else "Torch band kar di.")
        } catch (e: Throwable) {
            Result(false, "Torch control nahi hua: ${e.message ?: "camera busy"}")
        }
    }

    fun toggleTorch(context: Context): Result = setTorch(context, !Prefs.torchOn)

    // --------------------------------------------------------------- volume

    private fun audio(context: Context) =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun setVolumePercent(context: Context, percent: Int): Result {
        val am = audio(context)
        val stream = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(stream)
        val level = (max * percent / 100f).toInt().coerceIn(0, max)
        return try {
            am.setStreamVolume(stream, level, AudioManager.FLAG_SHOW_UI)
            Result(true, "Volume $percent% kar diya.")
        } catch (e: SecurityException) {
            // Do Not Disturb can block volume changes.
            Result(false, "Volume change block ho gaya. DND off karke try karo.")
        }
    }

    fun volumeStep(context: Context, up: Boolean): Result {
        val am = audio(context)
        val stream = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(stream)
        val cur = am.getStreamVolume(stream)
        val next = (if (up) cur + 1 else cur - 1).coerceIn(0, max)
        am.setStreamVolume(stream, next, AudioManager.FLAG_SHOW_UI)
        val pct = (next * 100f / max).toInt()
        return Result(true, "Volume ab $pct%.")
    }

    fun mute(context: Context, mute: Boolean): Result {
        val am = audio(context)
        val stream = AudioManager.STREAM_MUSIC
        return if (mute) {
            val cur = am.getStreamVolume(stream)
            Prefs.savedVolume = cur
            am.setStreamVolume(stream, 0, 0)
            Result(true, "Media mute kar diya.")
        } else {
            val max = am.getStreamMaxVolume(stream)
            val target = if (Prefs.savedVolume in 1..max) Prefs.savedVolume else max / 2
            am.setStreamVolume(stream, target, AudioManager.FLAG_SHOW_UI)
            Result(true, "Media ki awaz wapas on kar di.")
        }
    }

    // --------------------------------------------------------------- ringer

    fun setRinger(context: Context, mode: RingerMode): Result {
        val am = audio(context)
        val target = when (mode) {
            RingerMode.SILENT -> AudioManager.RINGER_MODE_SILENT
            RingerMode.VIBRATE -> AudioManager.RINGER_MODE_VIBRATE
            RingerMode.NORMAL -> AudioManager.RINGER_MODE_NORMAL
        }
        return try {
            if (NotificationManager::class.java.let {
                    context.getSystemService(it)?.isNotificationPolicyAccessGranted == false
                } && mode == RingerMode.SILENT
            ) {
                // On modern Android, putting the phone in silent needs DND access.
                openDndAccess(context)
                return Result(false, "Silent mode ke liye DND access chahiye. Settings khol di — allow karke phir bolo.")
            }
            am.ringerMode = target
            val msg = when (mode) {
                RingerMode.SILENT -> "Phone silent kar diya."
                RingerMode.VIBRATE -> "Vibration mode on kar diya."
                RingerMode.NORMAL -> "Ring mode on kar diya."
            }
            Result(true, msg)
        } catch (e: SecurityException) {
            Result(false, "Ringer badalne ki permission nahi mili (DND access do).")
        }
    }

    fun setDnd(context: Context, on: Boolean): Result {
        val nm = context.getSystemService(NotificationManager::class.java)
            ?: return Result(false, "Notification service nahi mila.")
        if (!nm.isNotificationPolicyAccessGranted) {
            openDndAccess(context)
            return Result(false, "DND access nahi hai. Settings khol di — Dark ko allow karo, phir bolo.")
        }
        return try {
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            Result(true, if (on) "Do Not Disturb on kar diya." else "Do Not Disturb off kar diya.")
        } catch (e: Throwable) {
            Result(false, "DND badal nahi paya: ${e.message}")
        }
    }

    // -------------------------------------------------------- radio switches

    fun setWifi(context: Context, on: Boolean): Result {
        // Direct toggling was removed from the public SDK in Android 10.
        // The closest allowed action is the system Wi-Fi panel.
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val i = Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                Result(true, "Wi-Fi panel khol diya — wahan se ${if (on) "on" else "off"} kar do. Android 10+ app se direct switch nahi hota.")
            } else {
                @Suppress("DEPRECATION")
                val wm = context.applicationContext
                    .getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                @Suppress("DEPRECATION")
                val ok = wm.isWifiEnabled != on && wm.setWifiEnabled(on)
                Result(ok, if (ok) "Wi-Fi ${if (on) "on" else "off"} kar diya." else "Wi-Fi nahi badla — panel khol raha hoon.")
            }
        } catch (e: Throwable) {
            Result(false, "Wi-Fi control nahi hua: ${e.message}")
        }
    }

    fun setBluetooth(context: Context, on: Boolean): Result {
        return try {
            val mgr = context.getSystemService(BluetoothManager::class.java)
            val adapter: BluetoothAdapter? = mgr?.adapter
                ?: return Result(false, "Is phone mein Bluetooth nahi hai.")
            val hasPerm = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
            if (!hasPerm) return Result(false, "Bluetooth ke liye permission chahiye.")
            if (adapter.isEnabled == on) {
                return Result(true, "Bluetooth pehle se ${if (on) "on" else "off"} hai.")
            }
            @Suppress("DEPRECATION")
            val ok = if (on) adapter.enable() else adapter.disable()
            if (ok) Result(true, "Bluetooth ${if (on) "on" else "off"} kar diya.")
            else Result(false, "Android ne Bluetooth toggle rok diya — Settings se kar do.")
        } catch (e: SecurityException) {
            Result(false, "Bluetooth permission nahi mili.")
        } catch (e: Throwable) {
            Result(false, "Bluetooth control nahi hua: ${e.message}")
        }
    }

    fun setAirplane(context: Context, on: Boolean): Result {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                val i = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                Result(true, "Airplane mode settings khol di — Android app se direct toggle allow nahi karta.")
            } else {
                @Suppress("DEPRECATION")
                Settings.System.putInt(
                    context.contentResolver,
                    Settings.System.AIRPLANE_MODE_ON,
                    if (on) 1 else 0
                )
                Result(true, "Airplane mode ${if (on) "on" else "off"} kar diya.")
            }
        } catch (e: Throwable) {
            Result(false, "Airplane mode nahi badla: ${e.message}")
        }
    }

    fun setHotspot(context: Context, on: Boolean): Result {
        return try {
            val i = Intent(Intent.ACTION_MAIN).apply {
                setClassName(
                    "com.android.settings",
                    "com.android.settings.TetherSettings"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(i)
            Result(true, "Hotspot settings khol di — Android app se direct hotspot on nahi hota.")
        } catch (e: Throwable) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Result(true, "Network settings khol di.")
            } catch (e2: Throwable) {
                Result(false, "Hotspot settings nahi khuli.")
            }
        }
    }

    fun batterySaverSettings(context: Context): Result {
        return try {
            context.startActivity(
                Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Result(true, "Battery saver settings khol di.")
        } catch (e: Throwable) {
            Result(false, "Battery saver settings nahi khuli.")
        }
    }

    fun openDndAccess(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) { }
    }

    // ---------------------------------------------------------------- alarms

    fun setAlarm(context: Context, hour: Int, minute: Int, label: String?): Result {
        return try {
            val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                if (!label.isNullOrBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(i)
            val h12 = if (hour % 12 == 0) 12 else hour % 12
            val ap = if (hour < 12) "AM" else "PM"
            Result(true, "Alarm set: %02d:%02d %s".format(h12, minute, ap))
        } catch (e: Throwable) {
            Result(false, "Alarm app nahi mila.")
        }
    }

    fun showAlarms(context: Context): Result {
        return try {
            context.startActivity(
                Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Result(true, "Alarms khol diye.")
        } catch (e: Throwable) {
            Result(false, "Alarm app nahi mila.")
        }
    }

    fun setTimer(context: Context, seconds: Int): Result {
        return try {
            val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(i)
            Result(true, "Timer ${formatDuration(seconds)} ka lag gaya.")
        } catch (e: Throwable) {
            Result(false, "Timer app nahi mila.")
        }
    }

    fun formatDuration(total: Int): String {
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add("$h ghanta")
        if (m > 0) parts.add("$m minute")
        if (s > 0) parts.add("$s second")
        return if (parts.isEmpty()) "0 second" else parts.joinToString(" ")
    }

    // ---------------------------------------------------------------- info

    fun batteryStatus(context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            bm.isCharging
        } else {
            val i = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        }
        val suffix = if (charging) " Aur charge ho rahi hai." else ""
        return "Battery $pct% hai.$suffix"
    }

    fun deviceInfo(context: Context): String {
        val pm = context.packageManager
        val appVer = try {
            pm.getPackageInfo(context.packageName, 0).versionName
        } catch (_: Throwable) { "?" }
        val ram = totalRamGb()
        val storage = totalStorageGb(context)
        return buildString {
            append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}. ")
            append("Android ${Build.VERSION.RELEASE}. ")
            if (ram > 0) append("RAM about ${"%.1f".format(ram)} GB. ")
            if (storage > 0) append("Internal storage ${"%.0f".format(storage)} GB. ")
            append("Main Dark Assistant v$appVer hoon.")
        }
    }

    private fun totalRamGb(): Double {
        return try {
            val raf = java.io.RandomAccessFile("/proc/meminfo", "r")
            val line = raf.readLine()
            raf.close()
            val kb = line.replace(Regex("[^0-9]"), "").toLongOrNull() ?: return 0.0
            kb / 1024.0 / 1024.0
        } catch (_: Throwable) { 0.0 }
    }

    private fun totalStorageGb(context: Context): Double {
        return try {
            val stat = android.os.StatFs(context.filesDir.absolutePath)
            stat.blockCountLong * stat.blockSizeLong / 1024.0 / 1024.0 / 1024.0
        } catch (_: Throwable) { 0.0 }
    }

    fun closeNotifications(context: Context): Result {
        val nm = context.getSystemService(NotificationManager::class.java)
            ?: return Result(false, "Notification service nahi mila.")
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) nm.cancelAll()
            Result(true, "Notifications clear kar diye.")
        } catch (e: Throwable) {
            Result(false, "Notifications clear nahi hue.")
        }
    }

    // -------------------------------------------------------------- helpers

    fun copyToClipboard(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Dark Assistant", text))
    }

    /** True when the user turned off battery optimisation for us. */
    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(PowerManager::class.java) ?: return false
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun requestIgnoreBatteryOptimizations(context: Context) {
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        } catch (_: Throwable) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) { }
        }
    }
}

/** Small result holder used by every action. */
data class Result(val ok: Boolean, val message: String)
