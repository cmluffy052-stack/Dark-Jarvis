package com.dark.assistant.engine

/**
 * Screen-level actions, implemented by [com.dark.assistant.services.ControlAccessibilityService].
 * Kept as an interface so the executor does not depend on the service directly.
 */
interface ScreenControl {

    /** True while the accessibility service is bound and usable. */
    fun isConnected(): Boolean

    fun back()
    fun home()
    fun recents()
    fun openNotifications()
    fun openQuickSettings()
    fun lockScreen()

    /** Reads visible text; the callback runs on the main thread. */
    fun readScreen(onText: (String) -> Unit)

    /** Takes a screenshot; the callback receives the saved file path. */
    fun screenshot(onSaved: (String) -> Unit)

    fun tapText(text: String)
    fun scroll(forward: Boolean)
    fun typeText(text: String)
    fun pressKey(key: KeyName)

    /** Current foreground app label, when known. */
    fun foregroundApp(): String?
}
