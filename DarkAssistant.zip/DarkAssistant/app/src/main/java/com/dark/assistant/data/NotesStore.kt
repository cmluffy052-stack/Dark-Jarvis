package com.dark.assistant.data

import android.content.Context
import java.io.File

/** Simple line-per-note store in the app's private files directory. */
object NotesStore {

    private fun file(context: Context) = File(context.filesDir, "notes.txt")

    fun add(context: Context, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val stamp = java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.US)
            .format(java.util.Date())
        file(context).appendText("$clean  ($stamp)\n")
    }

    fun all(context: Context): List<String> {
        val f = file(context)
        if (!f.exists()) return emptyList()
        return f.readLines().filter { it.isNotBlank() }.takeLast(50).reversed()
    }

    fun clear(context: Context) {
        val f = file(context)
        if (f.exists()) f.delete()
    }
}
