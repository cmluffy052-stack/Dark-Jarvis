package com.dark.assistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists the last conversation so a restart does not lose context. */
object ChatStore {

    data class Message(val text: String, val fromUser: Boolean)

    private const val MAX = 120
    private fun file(context: Context) = File(context.filesDir, "chat.json")

    fun load(context: Context): List<Message> {
        if (!Prefs.saveHistory) return emptyList()
        val f = file(context)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Message(o.getString("t"), o.getBoolean("u"))
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun save(context: Context, messages: List<Message>) {
        if (!Prefs.saveHistory) {
            clear(context)
            return
        }
        try {
            val arr = JSONArray()
            messages.takeLast(MAX).forEach { m ->
                arr.put(JSONObject().put("t", m.text).put("u", m.fromUser))
            }
            file(context).writeText(arr.toString())
        } catch (_: Throwable) { }
    }

    fun clear(context: Context) {
        val f = file(context)
        if (f.exists()) f.delete()
    }
}
