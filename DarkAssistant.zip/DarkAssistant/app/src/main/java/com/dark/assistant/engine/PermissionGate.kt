package com.dark.assistant.engine

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Single place that answers "is X allowed?" and "take me to the screen where I
 * can allow X". Keeps permission logic out of the UI and the executor.
 */
class PermissionGate(private val context: Context) {

    fun mic(): Boolean = runtime(Manifest.permission.RECORD_AUDIO)
    fun contacts(): Boolean = runtime(Manifest.permission.READ_CONTACTS)
    fun phone(): Boolean = runtime(Manifest.permission.CALL_PHONE)
    fun sms(): Boolean = runtime(Manifest.permission.SEND_SMS)
    fun answerCalls(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.P || runtime(Manifest.permission.ANSWER_PHONE_CALLS)

    fun notifications(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            runtime(Manifest.permission.POST_NOTIFICATIONS)

    fun overlay(): Boolean = Settings.canDrawOverlays(context)

    fun accessibilityEnabled(): Boolean {
        val expected = "${context.packageName}/${context.packageName}.services.ControlAccessibilityService"
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun notificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(context.packageName, ignoreCase = true)
    }

    fun batteryUnrestricted(): Boolean = DeviceControl.isIgnoringBatteryOptimizations(context)

    private fun runtime(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------ settings intents

    fun openAccessibilitySettings() = safeStart(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
    )

    fun openNotificationAccessSettings() = safeStart(
        Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
    )

    fun openOverlaySettings() = safeStart(
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
    )

    private fun safeStart(intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) { }
    }

    /** The list shown on the setup screen, in the order a user should grant it. */
    fun setupItems(): List<SetupItem> = listOf(
        SetupItem(
            key = "mic",
            title = "Microphone",
            subtitle = "Aawaz sunne ke liye — iske bina assistant baat nahi kar sakta.",
            granted = mic(),
            kind = Kind.RUNTIME,
            permission = Manifest.permission.RECORD_AUDIO
        ),
        SetupItem(
            key = "notifications",
            title = "Notifications",
            subtitle = "Chalne wali service ka status dikhane ke liye.",
            granted = notifications(),
            kind = Kind.RUNTIME,
            permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                Manifest.permission.POST_NOTIFICATIONS else null
        ),
        SetupItem(
            key = "contacts",
            title = "Contacts",
            subtitle = "Naam se call — \"Amit ko call karo\".",
            granted = contacts(),
            kind = Kind.RUNTIME,
            permission = Manifest.permission.READ_CONTACTS
        ),
        SetupItem(
            key = "phone",
            title = "Phone",
            subtitle = "Khud call lagane ke liye. Bina iske dialer khulega.",
            granted = phone(),
            kind = Kind.RUNTIME,
            permission = Manifest.permission.CALL_PHONE
        ),
        SetupItem(
            key = "sms",
            title = "SMS",
            subtitle = "Message bhejne ke liye. Bina iske draft banega.",
            granted = sms(),
            kind = Kind.RUNTIME,
            permission = Manifest.permission.SEND_SMS
        ),
        SetupItem(
            key = "accessibility",
            title = "Accessibility service",
            subtitle = "Back, home, recents, lock, screenshot, screen padhna, tap karna.",
            granted = accessibilityEnabled(),
            kind = Kind.ACCESSIBILITY
        ),
        SetupItem(
            key = "notif_access",
            title = "Notification access",
            subtitle = "Aane wale message/notification sunane ke liye.",
            granted = notificationAccess(),
            kind = Kind.NOTIFICATION_ACCESS
        ),
        SetupItem(
            key = "overlay",
            title = "Floating mic",
            subtitle = "Kisi bhi app ke upar chhota mic button.",
            granted = overlay(),
            kind = Kind.OVERLAY
        ),
        SetupItem(
            key = "battery",
            title = "Battery: no restrictions",
            subtitle = "Taaki assistant background mein band na ho.",
            granted = batteryUnrestricted(),
            kind = Kind.BATTERY
        )
    )

    enum class Kind { RUNTIME, ACCESSIBILITY, NOTIFICATION_ACCESS, OVERLAY, BATTERY }

    data class SetupItem(
        val key: String,
        val title: String,
        val subtitle: String,
        val granted: Boolean,
        val kind: Kind,
        val permission: String? = null
    )
}
