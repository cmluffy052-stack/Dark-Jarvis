package com.dark.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.dark.assistant.data.Prefs

/**
 * Thin wrapper over the platform speech recogniser.
 *
 * Uses the on-device recogniser when the phone offers one, and falls back to
 * the standard recogniser otherwise. Hindi is requested first because the
 * command vocabulary is Hindi/Hinglish.
 */
class SpeechInput(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    var onPartial: ((String) -> Unit)? = null
    var onResult: ((String) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onRms: ((Float) -> Unit)? = null
    var onListeningChanged: ((Boolean) -> Unit)? = null

    val isAvailable: Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start() {
        if (!isAvailable) {
            onError?.invoke("Is phone par speech recognizer nahi hai. Type karke bolo.")
            return
        }
        stop()
        main.post {
            val r = try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                } else {
                    SpeechRecognizer.createSpeechRecognizer(context)
                }
            } catch (t: Throwable) {
                try {
                    SpeechRecognizer.createSpeechRecognizer(context)
                } catch (t2: Throwable) {
                    onError?.invoke("Speech recognizer start nahi hua.")
                    return@post
                }
            }
            recognizer = r
            r.setRecognitionListener(listener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.language)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Prefs.language)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            }
            try {
                r.startListening(intent)
                onListeningChanged?.invoke(true)
            } catch (e: Throwable) {
                onError?.invoke("Mic start nahi hua.")
                onListeningChanged?.invoke(false)
            }
        }
    }

    fun stop() {
        main.post {
            try {
                recognizer?.stopListening()
                recognizer?.cancel()
                recognizer?.destroy()
            } catch (_: Throwable) { }
            recognizer = null
            onListeningChanged?.invoke(false)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            onListeningChanged?.invoke(true)
        }

        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) {
            onRms?.invoke(rmsdB)
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() {
            onListeningChanged?.invoke(false)
        }

        override fun onError(error: Int) {
            onListeningChanged?.invoke(false)
            val msg = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Mic audio problem."
                SpeechRecognizer.ERROR_CLIENT -> "Recognizer band ho gaya."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai."
                SpeechRecognizer.ERROR_NETWORK -> "Network issue — on-device recognizer try karo."
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout."
                SpeechRecognizer.ERROR_NO_MATCH -> "Kuch samajh nahi aaya, phir bolo."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai."
                SpeechRecognizer.ERROR_SERVER -> "Server error."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi aawaz nahi aayi."
                else -> "Sun nahi paya."
            }
            onError?.invoke(msg)
        }

        override fun onResults(results: Bundle?) {
            onListeningChanged?.invoke(false)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = list?.firstOrNull { it.isNotBlank() }?.trim()
            if (text.isNullOrEmpty()) {
                onError?.invoke("Kuch samajh nahi aaya, phir bolo.")
            } else {
                onResult?.invoke(text)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            list?.firstOrNull()?.let { onPartial?.invoke(it) }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }
}

/**
 * Text-to-speech with a Hindi-first voice. Falls back to the device default
 * language when Hindi is not installed.
 */
class SpeechOutput(context: Context) {

    private val tts: android.speech.tts.TextToSpeech
    private var ready = false
    private val pending = ArrayDeque<String>()
    private val context = context.applicationContext

    init {
        tts = android.speech.tts.TextToSpeech(context) { status ->
            ready = status == android.speech.tts.TextToSpeech.SUCCESS
            if (ready) {
                applyLanguage()
                flushPending()
            }
        }
    }

    private fun applyLanguage() {
        val langs = listOf(Prefs.language, "hi-IN", "en-IN")
        for (tag in langs) {
            val locale = java.util.Locale.forLanguageTag(tag)
            if (tts.isLanguageAvailable(locale) >= android.speech.tts.TextToSpeech.LANG_AVAILABLE) {
                tts.language = locale
                break
            }
        }
        tts.setSpeechRate(Prefs.speechRate)
    }

    fun refreshSettings() {
        if (ready) {
            applyLanguage()
            tts.setSpeechRate(Prefs.speechRate)
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pending.add(text)
            return
        }
        tts.speak(clean(text), android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "dark")
    }

    fun stop() {
        if (ready) tts.stop()
        pending.clear()
    }

    fun shutdown() {
        try { tts.stop(); tts.shutdown() } catch (_: Throwable) { }
    }

    private fun flushPending() {
        while (pending.isNotEmpty()) {
            tts.speak(clean(pending.removeFirst()), android.speech.tts.TextToSpeech.QUEUE_ADD, null, "dark")
        }
    }

    /** Strips characters that TTS reads out loud as words. */
    private fun clean(text: String): String {
        return text
            .replace("•", " ")
            .replace(Regex("[\\u2022\\u25CF]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
