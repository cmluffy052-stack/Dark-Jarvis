package com.dark.assistant.engine

/**
 * Rule based intent parser. Runs entirely on-device: no network, no model
 * download, so it responds in a millisecond and works offline.
 *
 * Rules are ordered from most specific to most general. Every rule checks the
 * normalised Roman-Hinglish sentence, so "टॉर्च चालू करो", "torch on karo" and
 * "flashlight on" all resolve to the same command.
 */
object CommandParser {

    /** Split patterns kept in one place so new phrasing is easy to add. */
    private val CALL_VERBS = listOf("call", "phone", "dial", "milao", "mila", "lagao", "laga")
    private val SMS_VERBS = listOf("sms", "message", "msg", "text")
    private val WA_VERBS = listOf("whatsapp", "wa", "watsapp")

    fun parse(rawInput: String): Command {
        val raw = rawInput.trim()
        if (raw.isEmpty()) return Command.Unknown("")

        val n = Normalizer.stripFillers(Normalizer.normalize(raw))
        if (n.isEmpty()) return Command.Unknown(raw)

        return parseNormalized(n, raw)
    }

    private fun parseNormalized(s: String, raw: String): Command {
        // ---------- Meta ----------
        if (matchesAny(s, listOf("stop", "ruko", "ruk jao", "chup", "shant ho jao", "quiet", "rehne do", "band ho jao"))) {
            return Command.Stop
        }
        if (matchesAny(s, listOf("help", "madad", "kya kar sakte ho", "what can you do", "commands", "kya kar sakta hai"))) {
            return Command.Help
        }
        if (Regex("^(hello|hi|hey|namaste|namaskar|salaam|salam|oye|ooye|sun|suno)\\b.*$").matches(s) &&
            s.split(' ').size <= 3
        ) {
            return Command.Say(greeting())
        }
        if (matchesAny(s, listOf("thank you", "thanks", "dhanyavad", "shukriya", "thx"))) {
            return Command.Say("Koi baat nahi. Aur kuch karun?")
        }
        if (matchesAny(s, listOf("kaise ho", "how are you", "kya haal", "kya chal raha"))) {
            return Command.Say("Main bilkul theek hoon. Tum batao, kya karna hai?")
        }
        if (matchesAny(s, listOf("tumhara naam", "your name", "kaun ho", "who are you", "tum kaun"))) {
            return Command.Say("Main Dark hoon. Tumhare phone ka assistant, poori tarah on-device.")
        }

        // ---------- Explicit "say this" ----------
        Regex("^(?:bolo|say|sunao|speak)\\s+(.{2,})$").find(s)?.let {
            return Command.Say(it.groupValues[1])
        }

        // ---------- Notes ----------
        Regex("^(?:note|yaad rakho|yaad rakh|remember|likho|likh do|save note)\\s*[:\\-]?\\s*(.{2,})$")
            .find(s)?.let { return Command.SaveNote(it.groupValues[1]) }
        if (matchesAny(s, listOf("notes dikhao", "mera notes", "read notes", "notes sunao", "notes padho", "saare notes"))) {
            return Command.ReadNotes
        }
        if (matchesAny(s, listOf("notes mitao", "notes delete", "clear notes", "notes hatao", "saare notes delete"))) {
            return Command.ClearNotes
        }

        // ---------- Volume ----------
        if (Regex("^(?:volume|awaz|aawaz|sound)\\s*(?:ko\\s*)?(\\d{1,3})\\s*(?:percent|%|par)?\\s*(?:kar do|karo|set karo|kar)?").matches(s)) {
            val v = Regex("(\\d{1,3})").find(s)!!.groupValues[1].toInt()
            return Command.Volume(v.coerceIn(1, 100))
        }
        if (matchesAny(s, listOf("mute", "mute karo", "mute kar do", "awaz band", "aawaz band karo", "sound off", "silent kar do", "silent mode"))) {
            return Command.Mute(true)
        }
        if (matchesAny(s, listOf("unmute", "unmute karo", "awaz chalu karo", "aawaz chalu", "sound on", "awaz wapas"))) {
            return Command.Mute(false)
        }
        if (Regex("(?:volume|awaz|aawaz|sound).*(?:badhao|up|increase|tez|zyada|full|max)").containsMatchIn(s) ||
            s == "volume up" || s == "awaz badhao"
        ) {
            return Command.VolumeStep(true)
        }
        if (Regex("(?:volume|awaz|aawaz|sound).*(?:kam|down|decrease|dhima|low|ghatao)").containsMatchIn(s) ||
            s == "volume down"
        ) {
            return Command.VolumeStep(false)
        }

        // ---------- Ringer / DND ----------
        if (Regex("(?:silent|sailent|shant).*(?:mode|kar do|karo|lagao|on|chalu)").containsMatchIn(s) ||
            matchesAny(s, listOf("silent", "phone silent", "silent karo"))
        ) {
            return Command.Ringer(RingerMode.SILENT)
        }
        if (Regex("(?:vibrate|vibration|vibrat).*(?:mode|kar do|karo|on|karo|lagao)").containsMatchIn(s) ||
            matchesAny(s, listOf("vibrate", "vibration mode"))
        ) {
            return Command.Ringer(RingerMode.VIBRATE)
        }
        if (Regex("(?:normal|ring|loud|general).*(?:mode|kar do|karo|on|karo)").containsMatchIn(s) ||
            matchesAny(s, listOf("ring mode", "normal mode", "sound mode", "loud mode"))
        ) {
            return Command.Ringer(RingerMode.NORMAL)
        }
        if (Regex("(?:do not disturb|dnd|disturb na karo)").containsMatchIn(s)) {
            val off = Regex("(?:off|band|hatao|disable|mat karo)").containsMatchIn(s)
            return Command.Dnd(!off)
        }

        // ---------- Torch ----------
        if (Regex("(?:torch|flashlight|flash light|light on karo|roshni)").containsMatchIn(s)) {
            val off = Regex("(?:off|band|bujha|bujhao|close|hatao|disable)").containsMatchIn(s)
            val on = Regex("(?:on|chalu|jala|jalao|start|open|enable)").containsMatchIn(s)
            return when {
                off -> Command.Torch(false)
                on -> Command.Torch(true)
                s.contains("toggle") -> Command.ToggleTorchAgain
                else -> Command.ToggleTorchAgain
            }
        }

        // ---------- Connectivity ----------
        Regex("(?:wifi|wi fi|wi-fi|internet)").find(s)?.let {
            val off = Regex("(?:off|band|disable|hatao)").containsMatchIn(s)
            return Command.Wifi(!off)
        }
        Regex("(?:bluetooth|bt)").find(s)?.let {
            val off = Regex("(?:off|band|disable|hatao)").containsMatchIn(s)
            return Command.Bluetooth(!off)
        }
        Regex("(?:airplane|aeroplane|flight)\\s*mode|(?:udan)\\s*mode|hawai").find(s)?.let {
            val off = Regex("(?:off|band|disable|hatao)").containsMatchIn(s)
            return Command.Airplane(!off)
        }
        Regex("(?:hotspot|tethering)").find(s)?.let {
            val off = Regex("(?:off|band|disable|hatao)").containsMatchIn(s)
            return Command.Hotspot(!off)
        }
        Regex("(?:battery saver|power saver|battery bachao)").find(s)?.let {
            val off = Regex("(?:off|band|disable|hatao)").containsMatchIn(s)
            return Command.BatterySaver(!off)
        }

        // ---------- Alarms / timers ----------
        if (Regex("(?:alarm|uto|uthana).*(?:set|lagao|laga|banao|daal)").containsMatchIn(s) ||
            Regex("(?:set|lagao|laga).*(?:alarm)").containsMatchIn(s) ||
            Regex("\\d{1,2}.*baje.*(?:alarm|uthana|jagana)").containsMatchIn(s)
        ) {
            val t = Normalizer.parseTime(s)
                ?: return Command.Unknown(raw)
            val label = Regex("(?:alarm|uthana|jagana)\\s*(.*)$").find(s)?.groupValues?.get(1)?.trim()
            return Command.SetAlarm(t.first, t.second, label?.ifEmpty { null })
        }
        if (Regex("(?:timer|ghadi).*(?:set|lagao|laga|chalu|start)").containsMatchIn(s) ||
            Regex("(?:set|lagao|start)\\s*(?:a|ek)?\\s*timer").containsMatchIn(s) ||
            Regex("\\d+\\s*(?:minute|min|second|sec|ghanta|ghante|hour|hr).*timer").containsMatchIn(s) ||
            Regex("timer.*\\d+\\s*(?:minute|min|second|sec|ghanta|ghante|hour)").containsMatchIn(s)
        ) {
            val secs = Normalizer.parseDurationSeconds(s)
                ?: return Command.Unknown(raw)
            return Command.SetTimer(secs)
        }
        if (matchesAny(s, listOf("alarms dikhao", "mera alarms", "alarm list", "show alarms", "kitne alarm"))) {
            return Command.ShowAlarms
        }

        // ---------- Calls / messaging ----------
        // "whatsapp par amit ko message bhejo"
        if (s.contains("whatsapp") || s.contains("watsapp") || s.contains("wa par")) {
            if (Regex("(?:call|video call)").containsMatchIn(s)) {
                Normalizer.extractContact(s, WA_VERBS + CALL_VERBS)?.let {
                    return Command.WhatsappCall(it)
                }
            }
            val msg = extractMessageBody(s)
            Normalizer.extractContact(s, SMS_VERBS + WA_VERBS)?.let { contact ->
                return Command.SendWhatsapp(contact, msg)
            }
            // "whatsapp kholo" with no contact -> open the app
            if (!Regex("(?:message|msg|bhejo|bhej)").containsMatchIn(s)) {
                return Command.OpenApp("whatsapp")
            }
        }

        if (Regex("(?:sms|message|msg|text)\\b").containsMatchIn(s) ||
            Regex("(?:message|msg)\\s*(?:bhejo|bhej|bhejna|send)").containsMatchIn(s)
        ) {
            val msg = extractMessageBody(s)
            Normalizer.extractContact(s, SMS_VERBS)?.let { contact ->
                return Command.SendSms(contact, msg ?: "")
            }
            if (msg != null) return Command.SendSms("", msg)
        }

        if (Regex("\\bcall\\b").containsMatchIn(s) || Regex("(?:phone|dial|milao)\\s*(?:karo|kar|lagao)?").containsMatchIn(s)) {
            val speaker = Regex("(?:speaker|loudspeaker|speaker par|speaker pe)").containsMatchIn(s)
            val contact = Normalizer.extractContact(s, CALL_VERBS)
            if (contact != null && contact.isNotEmpty()) return Command.Call(contact, speaker)
            if (Regex("(?:uthao|utha|receive|accept|answer)").containsMatchIn(s)) return Command.AnswerCall(true)
            if (Regex("(?:kato|kata|cut|reject|decline|band)").containsMatchIn(s)) return Command.AnswerCall(false)
        }
        if (Regex("(?:call )?(?:uthao|utha lo|receive karo|accept karo|answer karo)").containsMatchIn(s)) {
            return Command.AnswerCall(true)
        }
        if (Regex("(?:call )?(?:kato|kata do|cut karo|reject karo|decline karo)").containsMatchIn(s)) {
            return Command.AnswerCall(false)
        }

        // ---------- Music ----------
        // Pause/stop has to be checked first: "music band karo" also contains
        // "music", so the play rule below would otherwise swallow it.
        if (matchesAny(
                s,
                listOf(
                    "pause", "pause karo", "roko", "gana roko", "gaana roko", "music roko",
                    "music band", "gana band", "gaana band", "stop music", "music pause"
                )
            )
        ) {
            return Command.PressKey(KeyName.SPACE)
        }
        if (Regex("(?:gana|gane|gaana|gaane|music|song|bajao|baja do|play)").containsMatchIn(s) &&
            !Regex("(?:video|youtube)").containsMatchIn(s)
        ) {
            return Command.PlayMusic(extractMusicQuery(s))
        }

        // ---------- Screenshot / screen control ----------
        if (Regex("(?:screenshot|screen shot|screen capture|photo lo|screen ki photo)").containsMatchIn(s)) {
            return Command.TakeScreenshot
        }
        if (matchesAny(s, listOf("screen padho", "read screen", "screen par kya hai", "kya likha hai", "screen batao", "read this"))) {
            return Command.ReadScreen
        }
        if (matchesAny(s, listOf("back", "wapas", "piche", "go back", "back jao", "wapas jao"))) {
            return Command.GoBack
        }
        if (matchesAny(s, listOf("home", "home jao", "ghar jao", "go home", "home screen"))) {
            return Command.GoHome
        }
        if (matchesAny(s, listOf("recent apps", "recents", "recent", "recent dikhao", "app switch"))) {
            return Command.ShowRecents
        }
        if (matchesAny(s, listOf("notification panel", "notifications kholo", "notification dikhao", "shade kholo"))) {
            return Command.ShowNotifications
        }
        if (matchesAny(s, listOf("quick settings", "settings panel", "control center"))) {
            return Command.QuickSettings
        }
        if (Regex("(?:notification|notifications).*(?:clear|hatao|saaf|delete)").containsMatchIn(s) ||
            Regex("(?:clear|hatao|saaf|delete).*(?:notification|notifications)").containsMatchIn(s)
        ) {
            return Command.ClearNotifications
        }
        if (Regex("(?:phone |screen |device )?lock (?:karo|kar do|kar de)?$").containsMatchIn(s) && !s.contains("unlock")) {
            return Command.LockScreen
        }
        Regex("^(?:tap|click|dabao|daba do)\\s+(?:on\\s+)?(.{1,40})$").find(s)?.let {
            return Command.TapText(it.groupValues[1].trim())
        }
        if (Regex("(?:scroll|niche|upar|neeche)\\s*(?:karo|kar do)?").matches(s)) {
            val up = s.contains("upar") || s.contains("up")
            return Command.Scroll(!up)
        }
        Regex("^(?:type|likho|type karo)\\s+(.{1,120})$").find(s)?.let {
            return Command.TypeText(it.groupValues[1])
        }
        if (matchesAny(s, listOf("enter", "enter dabao", "enter karo"))) return Command.PressKey(KeyName.ENTER)
        if (matchesAny(s, listOf("backspace", "backspace dabao", "delete"))) return Command.PressKey(KeyName.BACKSPACE)

        // ---------- Information ----------
        if (Regex("(?:battery|charge).*(?:kitna|kitni|status|percent|batao|dikhao)|(?:kitni|kitna).*(?:battery|charge)").containsMatchIn(s)) {
            return Command.BatteryStatus
        }
        if (matchesAny(s, listOf("battery", "battery status", "charge"))) return Command.BatteryStatus
        if (Regex("(?:time|samay|kitne baje|waqt)").containsMatchIn(s) &&
            !Regex("(?:alarm|timer|set|lagao)").containsMatchIn(s)
        ) {
            return Command.TimeNow
        }
        if (Regex("(?:date|tarikh|aaj kaunsa din|kya din hai|today|day)").containsMatchIn(s) &&
            !Regex("(?:alarm|timer)").containsMatchIn(s)
        ) {
            return Command.DateToday
        }
        if (Regex("(?:phone|device|mobile).*(?:info|details|kaunsa|model|kitna ram|storage)").containsMatchIn(s) ||
            matchesAny(s, listOf("device info", "phone info", "mera phone kaunsa hai"))
        ) {
            return Command.DeviceInfo
        }
        if (Regex("(?:mausam|weather|temperature|garmi|barish)").containsMatchIn(s)) {
            val city = Regex("(?:mausam|weather|temperature)\\s*(?:ka|in|of|at)?\\s*([a-z ]{2,30})")
                .find(s)?.groupValues?.get(1)?.trim()?.ifEmpty { null }
            return Command.Weather(city)
        }

        // ---------- Maths ----------
        if (Regex("^(?:calculate|kitna hota hai|kitna hua|what is|solve)\\s+(.+)$").containsMatchIn(s) ||
            Regex("^[0-9+\\-*/. ()%x×÷]+$").matches(s) && Regex("[+\\-*/x×÷]").containsMatchIn(s)
        ) {
            val expr = Regex("^(?:calculate|kitna hota hai|kitna hua|what is|solve)\\s+(.+)$")
                .find(s)?.groupValues?.get(1) ?: s
            return Command.Calculate(expr)
        }

        // ---------- Navigation & search ----------
        Regex("^(?:navigate|rasta batao|le chalo|direction|map par)\\s+(?:to|tak|par|ka)?\\s*(.{2,60})$")
            .find(s)?.let { return Command.Navigate(it.groupValues[1].trim()) }
        Regex("^(?:youtube par|youtube pe|youtube)\\s+(.{2,80})$").find(s)?.let {
            return Command.SearchYoutube(it.groupValues[1].trim())
        }
        Regex("^(?:search|google|dhundo|khojo|dhoondo)\\s+(.{2,100})$").find(s)?.let {
            return Command.SearchWeb(it.groupValues[1].trim())
        }
        Regex("^(https?://\\S+|www\\.\\S+)$").find(s)?.let { return Command.OpenUrl(it.groupValues[1]) }

        // ---------- Settings screens ----------
        Regex("^(?:settings|setting)\\s+(?:ka|ki|me|mein)?\\s*(.+?)\\s*(?:kholo|khol do|open|jao)?$")
            .find(s)?.let {
                val screen = it.groupValues[1].trim()
                if (screen.isNotEmpty()) return Command.OpenSettings(screen)
            }
        if (matchesAny(s, listOf("settings kholo", "settings", "setting kholo", "open settings"))) {
            return Command.OpenSettings("")
        }

        // ---------- Open app / app shortcuts ----------
        Regex("^(?:app|application)?\\s*(?:kholo|khol do|open|chalao|start)\\s+(.{2,40})$").find(s)?.let {
            return Command.OpenApp(it.groupValues[1].trim())
        }
        Regex("^(.{2,40}?)\\s*(?:app|application)\\s*(?:kholo|khol do|open|chalao)$").find(s)?.let {
            return Command.OpenApp(it.groupValues[1].trim())
        }
        Regex("^(.{2,40}?)\\s*(?:kholo|khol do|kholna|chalao|chalu karo|open karo)$").find(s)?.let {
            val target = it.groupValues[1].trim()
            if (target.isNotEmpty()) return Command.OpenApp(target)
        }

        return Command.Unknown(raw)
    }

    // ------------------------------------------------------------------ utils

    /**
     * "arijit singh ke gane bajao" -> "arijit singh"
     * Strips the verbs and possessives but keeps the meaningful words.
     */
    private fun extractMusicQuery(s: String): String {
        var q = s
        q = q.replace(Regex("\\b(?:play|bajao|baja do|baja|chalao|chala|lagao|sunao|karo|kar)\\b"), " ")
        q = q.replace(Regex("\\b(?:gana|gane|gaana|gaane|song|songs|music|track|ka|ke|ki|ko|par|pe)\\b"), " ")
        return q.replace(Regex("\\s+"), " ").trim()
    }

    private fun matchesAny(s: String, phrases: List<String>): Boolean =
        phrases.any { s == it || s.startsWith("$it ") || s.endsWith(" $it") }

    /** Grabs the text after "message"/"bol do"/"likh do" style verbs. */
    private fun extractMessageBody(s: String): String? {
        val patterns = listOf(
            Regex("(?:message|msg|sms|text)\\s*(?:likho|likh do|bhejo|bhej do|send|bol do|ki)\\s*[:\\-]?\\s*(.+)$"),
            Regex("(?:ki|that|bolo)\\s+(.+?)\\s*(?:bhejo|bhej do|send karo|send)$"),
            Regex("(?:bhejo|bhej do|send karo|send)\\s*[:\\-]?\\s*(.+)$"),
            Regex("(?:likho|likh do)\\s+(.+)$")
        )
        for (p in patterns) {
            val m = p.find(s)
            if (m != null) {
                var body = m.groupValues[1].trim()
                body = body.replace(Regex("^(?:ki|that|to)\\s+"), "")
                body = body.replace(Regex("\\s*(?:bhejo|bhej do|send karo|send)$"), "")
                if (body.isNotEmpty()) return body
            }
        }
        return null
    }

    fun greeting(): String = "Haan, bolo. Main sun raha hoon."
}
