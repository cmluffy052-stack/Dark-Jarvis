package com.dark.assistant.data

import android.content.Context
import android.content.SharedPreferences

/** All user settings, written straight through to disk. */
object Prefs {

    private const val FILE = "dark_assistant_prefs"
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    var speakReplies: Boolean
        get() = sp.getBoolean("speak_replies", true)
        set(v) = sp.edit().putBoolean("speak_replies", v).apply()

    var announceNotifications: Boolean
        get() = sp.getBoolean("announce_notif", false)
        set(v) = sp.edit().putBoolean("announce_notif", v).apply()

    var wakeWordEnabled: Boolean
        get() = sp.getBoolean("wake_word", false)
        set(v) = sp.edit().putBoolean("wake_word", v).apply()

    var wakeWord: String
        get() = sp.getString("wake_phrase", "dark") ?: "dark"
        set(v) = sp.edit().putString("wake_phrase", v.trim().lowercase()).apply()

    var speechRate: Float
        get() = sp.getFloat("speech_rate", 1.0f)
        set(v) = sp.edit().putFloat("speech_rate", v.coerceIn(0.5f, 2.0f)).apply()

    var language: String
        get() = sp.getString("lang", "hi-IN") ?: "hi-IN"
        set(v) = sp.edit().putString("lang", v).apply()

    var confirmCalls: Boolean
        get() = sp.getBoolean("confirm_calls", true)
        set(v) = sp.edit().putBoolean("confirm_calls", v).apply()

    var confirmSms: Boolean
        get() = sp.getBoolean("confirm_sms", true)
        set(v) = sp.edit().putBoolean("confirm_sms", v).apply()

    var saveHistory: Boolean
        get() = sp.getBoolean("save_history", true)
        set(v) = sp.edit().putBoolean("save_history", v).apply()

    var floatingMic: Boolean
        get() = sp.getBoolean("floating_mic", false)
        set(v) = sp.edit().putBoolean("floating_mic", v).apply()

    var setupShown: Boolean
        get() = sp.getBoolean("setup_shown", false)
        set(v) = sp.edit().putBoolean("setup_shown", v).apply()

    /** Torch state we last commanded, used for "toggle". */
    var torchOn: Boolean
        get() = sp.getBoolean("torch_on", false)
        set(v) = sp.edit().putBoolean("torch_on", v).apply()

    /** Music volume saved before a "mute" command. */
    var savedVolume: Int
        get() = sp.getInt("saved_volume", -1)
        set(v) = sp.edit().putInt("saved_volume", v).apply()

    fun clearAll() = sp.edit().clear().apply()
}
