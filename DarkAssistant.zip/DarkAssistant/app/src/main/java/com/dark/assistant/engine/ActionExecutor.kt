package com.dark.assistant.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.dark.assistant.data.NotesStore
import com.dark.assistant.data.Prefs

/**
 * Executes a parsed [Command] against the real device.
 *
 * Every branch answers with a short Hinglish sentence which is both shown in
 * chat and spoken aloud. Nothing is faked: if a permission is missing the reply
 * says so and names the permission.
 */
class ActionExecutor(
    private val context: Context,
    private val permissions: PermissionGate,
    private val screenControl: ScreenControl?
) {

    /** Fired when a screenshot file is written. */
    var onScreenshot: ((String) -> Unit)? = null

    /** Fired with the text currently on screen. */
    var onScreenText: ((String) -> Unit)? = null

    fun execute(command: Command): String = run(command)

    private fun run(command: Command): String = when (command) {
        is Command.Say -> command.text
        Command.Stop -> "Theek hai, ruk gaya."
        Command.Help -> helpText()

        // --- apps ---
        is Command.OpenApp -> AppLauncher.open(context, command.app).message
        is Command.OpenUrl -> openUrl(command.url)
        is Command.SearchWeb -> search("https://www.google.com/search?q=", command.query, "Google")
        is Command.SearchYoutube -> search("https://m.youtube.com/results?search_query=", command.query, "YouTube")
        is Command.PlayMusic -> playMusic(command.query)
        is Command.Navigate -> navigate(command.place)
        is Command.OpenSettings -> AppLauncher.openSettings(context, command.screen).message

        // --- comms ---
        is Command.Call -> {
            if (!Prefs.confirmCalls) {
                CommsControl.call(context, command.contact, command.speaker).message
            } else {
                pending = { CommsControl.call(context, command.contact, command.speaker).message }
                pendingConfirmPrompt = "${command.contact} ko call karun?"
                ""
            }
        }
        is Command.SendSms -> sendSms(command)
        is Command.AnswerCall -> handleAnswer(command.accept)
        is Command.SendWhatsapp -> CommsControl.whatsapp(context, command.contact, command.message).message
        is Command.WhatsappCall -> CommsControl.whatsappCall(context, command.contact).message

        // --- hardware ---
        is Command.Torch -> DeviceControl.setTorch(context, command.on).message
        Command.ToggleTorchAgain -> DeviceControl.toggleTorch(context).message
        is Command.Wifi -> DeviceControl.setWifi(context, command.on).message
        is Command.Bluetooth -> DeviceControl.setBluetooth(context, command.on).message
        is Command.Airplane -> DeviceControl.setAirplane(context, command.on).message
        is Command.Hotspot -> DeviceControl.setHotspot(context, command.on).message
        is Command.Ringer -> DeviceControl.setRinger(context, command.mode).message
        is Command.Dnd -> DeviceControl.setDnd(context, command.on).message
        is Command.BatterySaver -> DeviceControl.batterySaverSettings(context).message

        // --- audio ---
        is Command.Volume -> DeviceControl.setVolumePercent(context, command.level).message
        is Command.VolumeStep -> DeviceControl.volumeStep(context, command.up).message
        is Command.Mute -> DeviceControl.mute(context, command.mute).message

        // --- time ---
        is Command.SetAlarm -> DeviceControl.setAlarm(context, command.hour, command.minute, command.label).message
        is Command.SetTimer -> DeviceControl.setTimer(context, command.seconds).message
        Command.ShowAlarms -> DeviceControl.showAlarms(context).message

        // --- screen ---
        Command.GoBack -> requireAccessibility("Back") { it.back() }
        Command.GoHome -> requireAccessibility("Home") { it.home() }
        Command.ShowRecents -> requireAccessibility("Recents") { it.recents() }
        Command.ShowNotifications -> requireAccessibility("Notification panel") { it.openNotifications() }
        Command.QuickSettings -> requireAccessibility("Quick settings") { it.openQuickSettings() }
        Command.LockScreen -> requireAccessibility("Lock") { it.lockScreen() }
        Command.ReadScreen -> requireAccessibility("Screen read") {
            it.readScreen { text -> onScreenText?.invoke(text) }
        }
        Command.TakeScreenshot -> requireAccessibility("Screenshot") {
            it.screenshot { path -> onScreenshot?.invoke(path) }
        }
        Command.ClearNotifications -> DeviceControl.closeNotifications(context).message
        is Command.TapText -> requireAccessibility("Tap") { it.tapText(command.text) }
        is Command.Scroll -> requireAccessibility("Scroll") { it.scroll(command.forward) }
        is Command.TypeText -> requireAccessibility("Type") { it.typeText(command.text) }
        is Command.PressKey -> requireAccessibility("Key") { it.pressKey(command.key) }

        // --- info ---
        Command.BatteryStatus -> DeviceControl.batteryStatus(context)
        Command.TimeNow -> timeNow()
        Command.DateToday -> dateToday()
        Command.DeviceInfo -> DeviceControl.deviceInfo(context)
        is Command.Weather -> weather(command.city)
        is Command.Calculate -> calculate(command.expression)

        // --- notes ---
        is Command.SaveNote -> {
            NotesStore.add(context, command.text)
            "Note kar liya: \"${command.text}\""
        }
        Command.ReadNotes -> {
            val notes = NotesStore.all(context)
            if (notes.isEmpty()) "Abhi koi note save nahi hai."
            else "Tumhare ${notes.size} note:\n" +
                notes.mapIndexed { i, n -> "${i + 1}. $n" }.joinToString("\n")
        }
        Command.ClearNotes -> {
            NotesStore.clear(context)
            "Saare notes delete kar diye."
        }

        is Command.Unknown -> unknownReply(command.raw)
    }

    // ------------------------------------------------------------- helpers

    /** Non-null when the last command needs a yes/no answer. */
    var pendingConfirmPrompt: String? = null
        private set

    /** Set when the last command was a call/SMS awaiting confirmation. */
    private var pending: (() -> String)? = null

    fun hasPendingConfirmation(): Boolean = pending != null

    fun confirmPending(): String? {
        val action = pending ?: return null
        pending = null
        pendingConfirmPrompt = null
        return action()
    }

    fun cancelPending(): String {
        pending = null
        pendingConfirmPrompt = null
        return "Theek hai, cancel kar diya."
    }

    private fun handleAnswer(accept: Boolean): String {
        val sdkOk = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P
        val perm = CommsControl.hasPermission(
            context, android.Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (!sdkOk || !perm) {
            return "Call uthane ya katne ke liye ANSWER_PHONE_CALLS permission chahiye. " +
                "Wo granted nahi hai, isliye main ye nahi kar sakta."
        }
        return try {
            val tm = context.getSystemService(android.telecom.TelecomManager::class.java)
                ?: return "Telecom service nahi mila."
            if (accept) {
                tm.acceptRingingCall()
                "Call receive kar li."
            } else {
                tm.endCall()
                "Call cut kar di."
            }
        } catch (e: Throwable) {
            "Call control nahi hua: ${e.message ?: "permission"}."
        }
    }

    private fun sendSms(c: Command.SendSms): String {
        if (c.message.isBlank()) return CommsControl.sendSms(context, c.contact, "").message
        if (!Prefs.confirmSms) return CommsControl.sendSms(context, c.contact, c.message).message
        pendingConfirmPrompt = "${c.contact} ko SMS bhejun: \"${c.message}\""
        pending = { CommsControl.sendSms(context, c.contact, c.message).message }
        return ""
    }

    private fun requireAccessibility(label: String, block: (ScreenControl) -> Unit): String {
        val control = screenControl
        if (control == null || !control.isConnected()) {
            permissions.openAccessibilitySettings()
            return "$label ke liye Accessibility service on karna padega. Settings khol di — Dark Assistant ko enable karke wapas aao."
        }
        return try {
            block(control)
            when (label) {
                "Screenshot" -> "Screenshot le liya."
                "Screen read" -> "Screen padh raha hoon…"
                "Back" -> "Back gaya."
                "Home" -> "Home screen par aa gaya."
                "Recents" -> "Recent apps khol diye."
                "Notification panel" -> "Notification panel khol diya."
                "Quick settings" -> "Quick settings khol diye."
                "Lock" -> "Screen lock kar diya."
                "Scroll" -> "Scroll kar diya."
                "Type" -> "Type kar diya."
                "Key" -> "Key dab gayi."
                else -> "Ho gaya."
            }
        } catch (e: Throwable) {
            "$label nahi hua: ${e.message ?: "unknown"}"
        }
    }

    private fun openUrl(url: String): String {
        return try {
            val full = if (url.startsWith("http")) url else "https://$url"
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(full)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "$url khol raha hoon."
        } catch (e: Throwable) {
            "Link nahi khula."
        }
    }

    private fun search(prefix: String, query: String, what: String): String {
        if (query.isBlank()) return "$what par kya search karna hai?"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(prefix + Uri.encode(query)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "$what par \"$query\" search kar raha hoon."
        } catch (e: Throwable) {
            "Browser nahi khula."
        }
    }

    private fun playMusic(query: String): String {
        return try {
            val i = Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (query.isNotBlank()) putExtra(android.app.SearchManager.QUERY, query)
            }
            context.startActivity(i)
            if (query.isBlank()) "Music play kar raha hoon." else "\"$query\" play kar raha hoon."
        } catch (e: Throwable) {
            try {
                search("https://m.youtube.com/results?search_query=", query, "YouTube")
            } catch (e2: Throwable) {
                "Koi music app nahi mila."
            }
        }
    }

    private fun navigate(place: String): String {
        return try {
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(place))
            context.startActivity(
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "$place ka rasta khol diya."
        } catch (e: Throwable) {
            "Maps app nahi mila."
        }
    }

    private fun timeNow(): String {
        val now = java.util.Calendar.getInstance()
        val h = now.get(java.util.Calendar.HOUR_OF_DAY)
        val m = now.get(java.util.Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val ap = if (h < 12) "AM" else "PM"
        return "Abhi %d:%02d %s baje hain.".format(h12, m, ap)
    }

    private fun dateToday(): String {
        val f = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale("hi", "IN"))
        return "Aaj ${f.format(java.util.Date())} hai."
    }

    private fun weather(city: String?): String {
        // No API key is bundled on purpose; open the weather result instead.
        val q = if (city.isNullOrBlank()) "weather today" else "weather in $city"
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Weather ka latest update khol diya — $q."
        } catch (e: Throwable) {
            "Weather nahi dikha paya."
        }
    }

    private fun calculate(expr: String): String {
        return try {
            val clean = expr.replace("x", "*").replace("×", "*").replace("÷", "/")
                .replace(" ", "")
            val value = Calc.eval(clean)
            if (value == null) "Calculation samajh nahi aayi: $expr"
            else {
                val pretty = if (value == value.toLong().toDouble()) value.toLong().toString()
                else "%.4f".format(value).trimEnd('0').trimEnd('.')
                "$expr = $pretty"
            }
        } catch (e: Throwable) {
            "Calculation nahi kar paya."
        }
    }

    private fun unknownReply(raw: String): String {
        val low = raw.lowercase().trim()
        if (low.isNotBlank() && !low.contains(' ') && low.length > 2) {
            val app = AppLauncher.resolve(context, low)
            if (app != null) {
                AppLauncher.open(context, low)
                return "${app.label} khol raha hoon."
            }
        }
        return "Samajh nahi aaya: \"$raw\". \"help\" bolo to poori list suna dunga."
    }

    fun helpText(): String = """
        Main ye sab kar sakta hoon — bas normal Hindi/Hinglish mein bolo:

        • Apps: "WhatsApp kholo", "Instagram kholo", "settings wifi kholo"
        • Calls: "Amit ko call karo", "Mummy ko phone lagao"
        • Message: "Rahul ko message bhejo main aa raha hoon"
        • WhatsApp: "Priya ko whatsapp message bhejo kal milte hain"
        • Torch: "Torch on karo", "flashlight band karo"
        • Volume: "volume 50 karo", "awaz badhao", "mute karo"
        • Mode: "silent mode", "vibration mode", "DND on karo"
        • Alarms: "7 baje ka alarm set karo", "10 minute ka timer lagao"
        • Screen: "screenshot lo", "back", "home", "recent apps", "screen padho", "phone lock karo"
        • Notifications: "notifications clear karo", "quick settings kholo"
        • Music: "Arijit Singh ke gane bajao"
        • Search: "youtube par lofi search karo", "google par weather dhundo"
        • Info: "battery kitni hai", "kitne baje hain", "device info"
        • Notes: "note yaad rakho doodh lana hai", "notes dikhao"
        • Math: "calculate 45 * 12"
        • Wi-Fi/Bluetooth: "wifi on karo", "bluetooth off karo"
    """.trimIndent()
}

/**
 * Tiny recursive-descent calculator. Handles + - * / % and parentheses, which
 * is enough for spoken sums.
 */
object Calc {

    fun eval(expr: String): Double? {
        return try {
            val p = Parser(expr)
            val v = p.expression()
            if (p.pos != expr.length) null else v
        } catch (_: Throwable) {
            null
        }
    }

    private class Parser(private val s: String) {
        var pos = 0

        fun expression(): Double {
            var v = term()
            while (pos < s.length) {
                when (s[pos]) {
                    '+' -> { pos++; v += term() }
                    '-' -> { pos++; v -= term() }
                    else -> return v
                }
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (pos < s.length) {
                when (s[pos]) {
                    '*' -> { pos++; v *= factor() }
                    '/' -> { pos++; v /= factor() }
                    '%' -> { pos++; v %= factor() }
                    else -> return v
                }
            }
            return v
        }

        private fun factor(): Double {
            if (pos < s.length && s[pos] == '+') { pos++; return factor() }
            if (pos < s.length && s[pos] == '-') { pos++; return -factor() }
            if (pos < s.length && s[pos] == '(') {
                pos++
                val v = expression()
                if (pos < s.length && s[pos] == ')') pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("bad number")
            return s.substring(start, pos).toDouble()
        }
    }
}